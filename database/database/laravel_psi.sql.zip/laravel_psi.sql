-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 21-05-2019 a las 04:05:55
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `laravel_psi`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `assignments`
--

CREATE TABLE `assignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `classroom_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `careers`
--

CREATE TABLE `careers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `university_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `enabled`, `created_at`, `updated_at`) VALUES
(1, 'Programação', 'programacao', 1, '2019-05-06 14:54:19', '2019-05-06 14:54:19'),
(2, 'Destaque', 'destaque', 1, '2019-05-06 19:59:03', '2019-05-06 19:59:03'),
(3, 'Trenamentos', 'trenamentos', 1, '2019-05-06 20:57:01', '2019-05-21 03:43:38'),
(4, 'Palestras', 'palestras', 1, '2019-05-06 20:57:13', '2019-05-06 20:57:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `classrooms`
--

CREATE TABLE `classrooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `module_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `classrooms`
--

INSERT INTO `classrooms` (`id`, `name`, `description`, `video`, `views`, `status`, `module_id`, `created_at`, `updated_at`) VALUES
(1, 'Vídeo Aula 1', 'Uma descrição qualquer', NULL, NULL, NULL, 1, '2019-05-06 14:54:20', '2019-05-06 14:54:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `total_hours` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `free` tinyint(1) NOT NULL DEFAULT '0',
  `price` double(10,2) DEFAULT NULL,
  `price_plots` double(10,2) DEFAULT NULL,
  `total_plots` int(11) DEFAULT NULL,
  `link_buy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `courses`
--

INSERT INTO `courses` (`id`, `name`, `url`, `description`, `image`, `code`, `total_hours`, `published`, `free`, `price`, `price_plots`, `total_plots`, `link_buy`, `status`, `user_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 'JavaFX para iniciantes', 'javafx-para-iniciantes', 'Uma descrição qualquer 1', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, '2019-05-06 14:54:20', '2019-05-06 14:54:20'),
(2, 'VueJS para iniciantes', 'vuejs-para-iniciantes', 'Uma descrição qualquer 2', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, '2019-05-06 14:54:20', '2019-05-06 14:54:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu` int(10) UNSIGNED NOT NULL,
  `depth` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_08_11_073824_create_menus_wp_table', 1),
(4, '2017_08_11_074006_create_menu_items_wp_table', 1),
(5, '2019_02_07_201823_create_sections_table', 1),
(6, '2019_02_07_201942_create_pages_table', 1),
(7, '2019_02_07_202016_create_categories_table', 1),
(8, '2019_02_07_202439_create_posts_table', 1),
(9, '2019_02_07_202551_create_universities_table', 1),
(10, '2019_02_07_202728_create_careers_table', 1),
(11, '2019_02_07_203244_create_periods_table', 1),
(12, '2019_02_07_203304_create_trainees_table', 1),
(13, '2019_03_22_235123_create_courses_table', 1),
(14, '2019_03_22_235437_create_modules_table', 1),
(15, '2019_03_22_235738_create_classrooms_table', 1),
(16, '2019_03_23_134213_create_sales_table', 1),
(17, '2019_04_10_204906_create_permission_tables', 1),
(18, '2019_04_19_161613_create_assignments_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(2, 'App\\User', 2),
(3, 'App\\User', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modules`
--

CREATE TABLE `modules` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `modules`
--

INSERT INTO `modules` (`id`, `name`, `description`, `status`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 'a', 'Animi soluta amet distinctio nam.', NULL, 1, '2019-05-06 14:54:20', '2019-05-06 14:54:20'),
(2, 'quaerat', 'Repellendus autem animi voluptatem aut beatae vitae tempora.', NULL, 1, '2019-05-06 14:54:20', '2019-05-06 14:54:20'),
(3, 'aliquid', 'Omnis ex rem eveniet corrupti ducimus.', NULL, 1, '2019-05-06 14:54:20', '2019-05-06 14:54:20'),
(4, 'cum', 'Enim fugit eius error et iste.', NULL, 1, '2019-05-06 14:54:20', '2019-05-06 14:54:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `redirect` int(11) DEFAULT NULL,
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `section_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pages`
--

INSERT INTO `pages` (`id`, `parent_id`, `title`, `slug`, `description`, `content`, `enabled`, `redirect`, `external_url`, `target`, `order`, `section_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 0, 'Home', 'home', '<p>home</p>', '<p>home</p>', 1, 1, '/#inicio', '_parent', 1, 1, 3, '2019-05-06 16:55:57', '2019-05-13 00:01:34'),
(2, 0, 'Quem somos', 'quem-somos', NULL, '<div class=\"content-wrap\">\r\n<section id=\"vision\" class=\"section white-blue\">\r\n<div class=\"container\">\r\n<div class=\"target-big col-md-4 col-sm-4 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/Bem-vindo.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n<div class=\"col-md-8 col-sm-8 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Seja Bem Vindo!</h3>\r\n<p class=\"oriental\">A Pr&oacute;-Sa&uacute;de Integral</p>\r\n<p id=\"visao\" class=\"mission-text\" style=\"color: #363636;\">A Pr&oacute;-Sa&uacute;de Integral &eacute; uma Empresa comprometida com a promo&ccedil;&atilde;o da sa&uacute;de integral envolvendo os aspectos f&iacute;sico, mental e social atrav&eacute;s da mudan&ccedil;a de h&aacute;bitos e estilo de vida, potencializando significativamente o desenvolvimento integral do ser e o desenvolvimento intra e inter-pessoal.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<section id=\"mission\" class=\"section blue-light-2\">\r\n<div class=\"container\">\r\n<div class=\"mission-text-box col-md-8 col-sm-8 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Filosofia</h3>\r\n<p class=\"oriental\">Nossas a&ccedil;&otilde;es est&atilde;o alinhadas com nossos valores</p>\r\n<p class=\"mission-text\">Promover a sa&uacute;de f&iacute;sica, mental e social atrav&eacute;s da mudan&ccedil;a de h&aacute;bitos e estilo de vida, potencializando significativamente o desempenho intra e inter-pessoal e profissional, desenvolvendo maior sociabilidade no ambiente de trabalho e demais grupos sociais.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm col-md-4 col-sm-4 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"vision-img img-responsive\" src=\"http://127.0.0.1:8000/img/psi/filosofia.png\" alt=\"Nossa Miss&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"vision\" class=\"section white-blue\">\r\n<div class=\"container\">\r\n<div class=\"target-big col-md-4 col-sm-4 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/visao.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n<div class=\"col-md-8 col-sm-8 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Miss&atilde;o</h3>\r\n<p class=\"oriental\">A nossa raz&atilde;o de exist&ecirc;ncia</p>\r\n<p id=\"visao\" class=\"mission-text\" style=\"color: #363636;\">Atuar, atrav&eacute;s de uma experiente equipe multidisciplinar de profissionais especializados, de forma din&acirc;mica, criativa, consciente e com qualidade, promovendo atrav&eacute;s do cuidado integral, condi&ccedil;&otilde;es para que os clientes e as corpora&ccedil;&otilde;es empresariais desenvolvam suas atividades com seguran&ccedil;a, conforto e maior efici&ecirc;ncia, obtendo produtividade com qualidade. Facilitar o acesso das pessoas a orienta&ccedil;&otilde;es quanto a um viver saud&aacute;vel, Promovendo a recupera&ccedil;&atilde;o do estado de sa&uacute;de de nossos clientes, atrav&eacute;s de m&eacute;todos comprovadamente eficientes e com aten&ccedil;&atilde;o personalizada, utilizando m&eacute;todos preventivos.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm target-small col-md-4 col-sm-4 wow fadeInLeft animated\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/visao.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"mission\" class=\"section blue-light-2\">\r\n<div class=\"container\">\r\n<div class=\"mission-text-box col-md-8 col-sm-8 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Vis&atilde;o</h3>\r\n<p class=\"oriental\">Aonde n&oacute;s queremos chegar</p>\r\n<p class=\"mission-text\">Ser refer&ecirc;ncia em atendimento e promo&ccedil;&atilde;o da sa&uacute;de, atrav&eacute;s do conceito que parte da preven&ccedil;&atilde;o e diagn&oacute;stico para oferecer muito mais qualidade de vida. Cremos que os seres humanos podem adquirir melhor sa&uacute;de a fim de desenvolverem uma vida mais produtiva e plena de sentido que d&ecirc; valor e dignidade &agrave; essa exist&ecirc;ncia, ajudando os semelhantes a viverem com dignidade no presente e ensinando-os a serem mais longevos e com qualidade de vida.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm col-md-4 col-sm-4 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"vision-img img-responsive\" src=\"http://127.0.0.1:8000/img/psi/missao.png\" alt=\"Nossa Miss&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"vision\" class=\"section white-blue\">\r\n<div class=\"container\">\r\n<div class=\"target-big col-md-4 col-sm-4 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/lema.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n<div class=\"col-md-8 col-sm-8 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Lema</h3>\r\n<!--<p class=\"oriental\">A nossa razão de existência</p>-->\r\n<p id=\"visao\" class=\"mission-text\" style=\"color: #363636;\">Acesso &agrave; sa&uacute;de integral e acessibilidade a todos que desejam mais sa&uacute;de e longevidade.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm target-small col-md-4 col-sm-4 wow fadeInLeft animated\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/lema.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"values\" class=\"section blue-light-2\">\r\n<div class=\"container\">\r\n<div class=\"col-md-8 col-sm-8 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Valores</h3>\r\n<p class=\"oriental\">&nbsp;</p>\r\n<ul id=\"Valores\" class=\"mission-text list-item\">\r\n<li>Atendimento humanizado</li>\r\n<li>Confian&ccedil;a e respeito nas rela&ccedil;&otilde;es</li>\r\n<li>Transpar&ecirc;ncia e &eacute;tica</li>\r\n<li>Qualidade total em todos os processos</li>\r\n<li>Trabalho em equipe</li>\r\n<li>Inova&ccedil;&atilde;o e Responsabilidade social</li>\r\n</ul>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm col-md-4 col-sm-4 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"vision-img img-responsive\" src=\"http://127.0.0.1:8000/img/psi/valores.png\" alt=\"Nossos Valores\" /></div>\r\n</div>\r\n</section>\r\n</div>', 1, 1, '/quem-somos', '_parent', 2, 1, 3, '2019-05-06 16:57:35', '2019-05-21 04:21:39'),
(3, 0, 'Treinamentos', 'treinamentos', '<p>Treinamentos</p>', '<p>Treinamentos</p>', 1, 1, '/#treinamentos', '_parent', 3, 1, 3, '2019-05-06 16:58:16', '2019-05-13 00:11:08'),
(4, 0, 'Palestras', 'palestras', '<p>Palestras</p>', '<p>Palestras</p>', 1, 1, '/#palestras', '_parent', 4, 1, 3, '2019-05-06 16:58:57', '2019-05-13 00:11:22'),
(5, 0, 'Clinica', 'clinica', '<p>Clinica</p>', '<p>Clinica</p>', 1, 0, NULL, '_parent', 5, 1, 3, '2019-05-06 17:03:12', '2019-05-06 17:03:12'),
(6, 5, 'Clube da vantagens', 'clube-da-vantagens', '<p>Clube da vantagens</p>', '<div class=\"item-large-content\">\r\n<div class=\"item-header\">\r\n<h2 class=\"pull-left\">&nbsp;</h2>\r\n<div class=\"clearfix\">&nbsp;</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\"><img style=\"float: left; margin: 0px;\" src=\"http://127.0.0.1:8000/source/informacoes/psi-clube-de-vantagens.png\" width=\"520\" height=\"198\" /><strong><span style=\"font-size: 12pt;\">Aposte nesses benef&iacute;cios!&nbsp; <span style=\"color: #ff0000;\">Proteja seu bolso</span></span></strong></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 12pt;\">Para a Pr&oacute;-Sa&uacute;de Integral cuidar dos seus clientes &eacute; mais que oferecer atendimento e servi&ccedil;os de qualidade, &eacute; proporcionar uma solu&ccedil;&atilde;o completa em sa&uacute;de.&nbsp;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 12pt;\">Dessa forma, em parceria com uma extensa rede de estabelecimentos credenciados, foi desenvolvido especialmente para os clientes Pr&oacute;-Sa&uacute;de Integral o Clube de Vantagens. Uma s&eacute;rie de descontos em produtos e servi&ccedil;os relacionados &agrave; sa&uacute;de, qualidade de vida e bem-estar.</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 12pt;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral &eacute; uma vitrine de ofertas e benef&iacute;cios exclusivos para clientes Fidelidade. O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral tem o objetivo de fidelizar e aumentar a aproxima&ccedil;&atilde;o dos clientes com as empresas, por meio de ofertas e vantagens. A Pr&oacute;-Sa&uacute;de Integral tem compromisso em manter apenas parceiros que ofere&ccedil;am produtos e/ou servi&ccedil;os de&nbsp;<strong>qualidade.</strong></span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 12pt;\"><strong>Saiba como funciona</strong></span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 12pt;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral &eacute; uma rede de ofertas exclusiva para clientes Pr&oacute;-Sa&uacute;de Integral. Para usar os descontos do portal em lojas f&iacute;sicas, &eacute; necess&aacute;rio fazer o cadastro e obter cart&atilde;o Clin Card e apresent&aacute;-lo ao lojista no momento da compra. Caso tenha alguma d&uacute;vida, consulte a mec&acirc;nica de cada oferta.</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 12pt;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral n&atilde;o se responsabiliza por qualquer dano causado por parceiros.</span></p>\r\n<p>&nbsp;</p>\r\n</div>', 1, 0, NULL, '_parent', 1, 1, 3, '2019-05-06 17:04:03', '2019-05-06 17:04:03'),
(7, 5, 'Loja', 'loja', '<p>Loja</p>', '<p>Loja</p>', 1, 0, NULL, '_parent', 2, 1, 3, '2019-05-06 17:04:46', '2019-05-06 17:04:46'),
(8, 5, 'Dropdown2', 'dropdown2', '<p>Dropdown2</p>', '<p>Dropdown2</p>', 1, 0, NULL, '_parent', 3, 1, 3, '2019-05-06 17:22:51', '2019-05-06 17:25:14'),
(9, 8, 'Sub menu 2', 'sub-menu-2', '<p>Sub menu 2</p>', '<p>Sub menu 2</p>', 1, 0, NULL, '_parent', 1, 1, 3, '2019-05-06 17:23:30', '2019-05-06 17:23:30'),
(10, 8, 'Dropdown3', 'dropdown3', '<p>Dropdown3</p>', '<p>Dropdown3</p>', 1, 0, NULL, '_parent', 2, 1, 3, '2019-05-06 17:24:01', '2019-05-06 17:25:46'),
(11, 10, 'pertece a Dropdown3', 'pertece-a-dropdown3', '<p>pertece a Dropdown3</p>', '<p>pertece a Dropdown3</p>', 1, 0, NULL, '_parent', 1, 1, 3, '2019-05-06 17:26:20', '2019-05-06 17:26:20'),
(12, 0, 'Contato', 'contato', '<p>Contato</p>', '<p>Contato</p>', 1, 1, '/#contato', '_parent', 6, 1, 3, '2019-05-06 17:41:13', '2019-05-13 00:12:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periods`
--

CREATE TABLE `periods` (
  `id` int(10) UNSIGNED NOT NULL,
  `year` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'create user', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(2, 'read users', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(3, 'update user', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(4, 'delete user', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(5, 'create role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(6, 'read role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(7, 'update role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(8, 'delete role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(9, 'create permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(10, 'read permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(11, 'update permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(12, 'delete permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `image`, `content`, `date_start`, `date_end`, `description`, `target`, `status`, `external_url`, `redirect`, `author`, `order`, `category_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Clube de vantagens', 'clube-de-vantagens', '1557165057.jpg', '<p><strong><img style=\"border-width: 20px; border-style: inset; margin: 20px; float: left;\" src=\"http://127.0.0.1:8000/uploads/source/destaque/psi-clube-de-vantagens.png\" alt=\"\" width=\"520\" height=\"198\" />Aposte nesses benef&iacute;cios!&nbsp;&nbsp;Proteja seu bolso</strong></p>\r\n<p style=\"text-align: justify;\">Para a Pr&oacute;-Sa&uacute;de Integral cuidar dos seus clientes &eacute; mais que oferecer atendimento e servi&ccedil;os de qualidade, &eacute; proporcionar uma solu&ccedil;&atilde;o completa em sa&uacute;de.&nbsp;</p>\r\n<p style=\"text-align: justify;\">Dessa forma, em parceria com uma extensa rede de estabelecimentos credenciados, foi desenvolvido especialmente para os clientes Pr&oacute;-Sa&uacute;de Integral o Clube de Vantagens. Uma s&eacute;rie de descontos em produtos e servi&ccedil;os relacionados &agrave; sa&uacute;de, qualidade de vida e bem-estar.</p>\r\n<p style=\"text-align: justify;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral &eacute; uma vitrine de ofertas e benef&iacute;cios exclusivos para clientes Fidelidade. O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral tem o objetivo de fidelizar e aumentar a aproxima&ccedil;&atilde;o dos clientes com as empresas, por meio de ofertas e vantagens. A Pr&oacute;-Sa&uacute;de Integral tem compromisso em manter apenas parceiros que ofere&ccedil;am produtos e/ou servi&ccedil;os de&nbsp;<strong>qualidade.</strong></p>\r\n<p style=\"text-align: justify;\"><strong>Saiba como funciona</strong></p>\r\n<p style=\"text-align: justify;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral &eacute; uma rede de ofertas exclusiva para clientes Pr&oacute;-Sa&uacute;de Integral. Para usar os descontos do portal em lojas f&iacute;sicas, &eacute; necess&aacute;rio fazer o cadastro e obter cart&atilde;o Clin Card e apresent&aacute;-lo ao lojista no momento da compra. Caso tenha alguma d&uacute;vida, consulte a mec&acirc;nica de cada oferta.</p>\r\n<p style=\"text-align: justify;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral n&atilde;o se responsabiliza por qualquer dano causado por parceiros.</p>', '2019-05-06', '2019-05-31', '<p>Clube de vantagens</p>', '_parent', 1, 'http://127.0.0.1:8000/', '1', 'Eber Ortiz Mas', 1, 2, 3, '2019-05-06 20:04:16', '2019-05-06 20:50:57'),
(2, 'Equilibrio', 'equilibrio', '1557162668.jpg', '<p><span style=\"color: #000000;\">DESENVOLVA O EQUIL&Iacute;BRIO</span><br /><span style=\"color: #000000;\"> F&Iacute;SICO</span><br /><span style=\"color: #000000;\"> INTELECTUAL</span><br /><span style=\"color: #000000;\"> EMOCIONAL</span><br /><span style=\"color: #000000;\"> SOCIAL</span><br /><span style=\"color: #000000;\"> AMBIENTAL</span><br /><span style=\"color: #000000;\"> ESPIRITUAL</span></p>', '2019-05-06', '2019-05-31', 'DESENVOLVA O EQUILÍBRIO', '_parent', 1, NULL, '0', 'Eber Ortiz Mas', 2, 2, 3, '2019-05-06 20:11:08', '2019-05-06 20:11:08'),
(3, 'Atitude', 'atitude', '1557162825.jpg', '<p style=\"text-align: left;\"><strong><span style=\"font-size: 14pt;\"><span style=\"font-size: 24pt;\">Tenha uma gota de atitude</span> <br /></span></strong><br />Nada pode ser feito pelo ontem, <br />pois j&aacute; passou, nem pelo amanh&atilde;<br />pois n&atilde;o existe.<br />Viva integralmente o presente,<br />pois &eacute; o &uacute;nico presente que <br />Deus lhe deu. <br />Seu sucesso depende da atitude<br />tomada ap&oacute;s um grande tombo.</p>', '2019-05-06', '2019-05-31', '<p style=\"text-align: left;\"><strong><span style=\"font-size: 14pt;\"><span style=\"font-size: 24pt;\">Tenha uma gota de atitude</span> <br></span></strong><br> Nada pode ser feito pelo ontem, <br>pois já passou, nem pelo amanhã<br> pois não existe.<br>Viva integralmente o presente,<br> pois é o único presente que <br>Deus lhe deu. <br>Seu sucesso depende da atitude<br> tomada após um grande tombo.</p>', '_parent', 1, NULL, '0', NULL, 3, 2, 3, '2019-05-06 20:13:45', '2019-05-06 20:13:45'),
(4, 'O home', 'o-home', '1557162896.jpg', '<p style=\"text-align: center;\"><span style=\"font-size: 24pt;\"><strong>Por qu&ecirc; os homens surpreendem?</strong></span><br /><span style=\"font-size: 18pt;\">\"Porque perdem a sa&uacute;de para juntar dinheiro, depois perdem dinheiro para recuperar a sa&uacute;de.</span><br /><span style=\"font-size: 18pt;\">E por pensarem ansiosamente no futuro, esquecem do presente de tal forma que acabam por n&atilde;o viver nem o presente nem o futuro.</span><br /><span style=\"font-size: 18pt;\">E vivem como se nunca fossem morrer. E morrem como se nunca tivessem vivido.\"&nbsp;</span><br /><span style=\"font-size: 18pt;\"> Dalai Lama</span></p>', '2019-05-06', '2019-05-31', '<p style=\"text-align: center;\"><span style=\"font-size: 24pt;\"><strong>Por quê os homens surpreendem?</strong></span><br><span style=\"font-size: 18pt;\">\"Porque perdem a saúde para juntar dinheiro, depois perdem dinheiro para recuperar a saúde.</span><br><span style=\"font-size: 18pt;\">E por pensarem ansiosamente no futuro, esquecem do presente de tal forma que acabam por não viver nem o presente nem o futuro.</span><br><span style=\"font-size: 18pt;\">E vivem como se nunca fossem morrer. E morrem como se nunca tivessem vivido.\"&nbsp;</span><br><span style=\"font-size: 18pt;\"> Dalai Lama</span></p>', '_parent', 1, NULL, '0', NULL, 4, 2, 3, '2019-05-06 20:14:56', '2019-05-06 20:14:56'),
(5, 'Mente empreendedora', 'mente-empreendedora', '1558304980.jpg', '<h2 style=\"text-align: center;\">O que esperar do treinamento MENTE EMPREENDEDORA</h2>\r\n<p><img src=\"http://127.0.0.1:8000/uploads/source/treinamentos/9%20LICOES.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<h2 style=\"text-align: center;\">Voc&ecirc; deseja ter sucesso na vida? sente que sua vida poderia ser mais?</h2>\r\n<p style=\"text-align: justify;\">Anseia por deixar sua marca no mundo e tem o desejo de fazer a diferen&ccedil;a atrav&eacute;s de uma vida com prop&oacute;sito?<br />Tem um sonho, mas n&atilde;o sabe por onde come&ccedil;ar, pois n&atilde;o se sentiu ainda empoderado o suficiente para dar o primeiro passo?<br />Voc&ecirc; sente bem l&aacute; dentro como se estivesse faltando algo, uma pe&ccedil;a chave para viver uma vida mais m&aacute;gica, repleta de motiva&ccedil;&atilde;o e entusiasmo?</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; v&ecirc; que o mundo est&aacute; avan&ccedil;ando e que voc&ecirc; est&aacute; ficando para tr&aacute;s?</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; quer sentir-se como v&iacute;tima das circunstancias ou quer avan&ccedil;ar com o mundo, criando as circunst&acirc;ncias para o seu sucesso, sendo a estrela principal em seu pr&oacute;prio filme? Ent&atilde;o, <strong>viva com prop&oacute;sito!</strong> Tenha um sonho em mente e realize-o em sua vida!</p>\r\n<h2 style=\"text-align: center;\"><em>&ldquo;As pessoas de maior resultado t&ecirc;m<br />um forte prop&oacute;sito por tr&aacute;s de cada<br />a&ccedil;&atilde;o em sua vida&rdquo;</em></h2>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: center;\">Todos os vision&aacute;rios s&atilde;o movidos por um prop&oacute;sito definido em suas vidas.</p>\r\n<p style=\"text-align: center;\"><strong><u>o prop&oacute;sito &eacute; a chave para a transforma&ccedil;&atilde;o</u></strong><strong>.</strong></p>\r\n<p style=\"text-align: justify;\">O estudo acad&ecirc;mico te d&aacute; um conhecimento valioso, mas nunca te ensinou a pensar para o sucesso. Em casa, no trabalho e no meio de conviv&ecirc;ncia, voc&ecirc; n&atilde;o foi ensinado nem estimulado sobre prop&oacute;sito de vida e estrat&eacute;gias para ser uma pessoa de sucesso. Isso culmina com confus&atilde;o, frustra&ccedil;&atilde;o e fracasso. Por isso muitos n&atilde;o conseguem ser bem sucedidos na vida.</p>\r\n<p>Se voc&ecirc; &eacute; uma pessoa que:</p>\r\n<ul>\r\n<li>Gostaria de alterar radicalmente pelo menos uma &aacute;rea de sua vida.</li>\r\n<li>J&aacute; &nbsp;tentou fazer isso antes, mas n&atilde;o obteve os resultados desejados.</li>\r\n<li>N&atilde;o est&aacute; pronto para desistir de uma vida mais feliz e mais gratificante.</li>\r\n<li>Est&aacute; insatisfeito com sua situa&ccedil;&atilde;o atual e deseja mudar, mas n&atilde;o sabe como.</li>\r\n<li>Tem um sonho (conseguir algo ou ser algo) que deseja realizar.</li>\r\n<li>Se considera incapaz.</li>\r\n<li>Quer ser bem sucedido na vida.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: center;\"><strong>Atrav&eacute;s desse treinamento voc&ecirc; ir&aacute; transformar todos os seus conceitos e vis&atilde;o de mundo.</strong></p>\r\n<p style=\"text-align: justify;\"><strong>&nbsp;</strong></p>\r\n<p style=\"padding-left: 40px;\">Ent&atilde;o, o que voc&ecirc; realmente quer para sua vida?<br />N&atilde;o se contente com o que voc&ecirc; acha que pode conseguir ...<br />N&atilde;o deixe que o medo, a sobrecarga ou os maus h&aacute;bitos o impe&ccedil;am.<br />Essa &eacute; sua vida. E voc&ecirc; merece e pode ter o melhor.<br />Se voc&ecirc; acha que vai chegar onde quer por acaso, pense novamente.&nbsp;&nbsp;&nbsp;&nbsp;<strong>&nbsp;<br /><br /></strong></p>\r\n<p style=\"text-align: center;\">O <strong>sucesso</strong> n&atilde;o ocorre por acaso!</p>\r\n<p style=\"text-align: justify;\">Atrav&eacute;s de um prop&oacute;sito definido e planos estrat&eacute;gicos bem elaborados voc&ecirc; adquirir&aacute; a autoconfian&ccedil;a e determina&ccedil;&atilde;o para criar a vida que voc&ecirc; realmente deseja, para perseguir seus maiores objetivos e assumir o controle de sua vida, experimentando a verdadeira satisfa&ccedil;&atilde;o de um viver com realiza&ccedil;&atilde;o plena.</p>\r\n<p style=\"text-align: justify;\">Com o treinamento de Coaching <strong>MENTE EMPREENDEDORA</strong> &ndash; <em>As Chaves que Maximizam Seus Potenciais para o Sucesso</em>, voc&ecirc; ir&aacute; desvendar os segredos do potencial humano atrav&eacute;s de um estudo profundo da mente, como &eacute; que voc&ecirc; se torna o que pensa e caminha rumo a um prop&oacute;sito definido para uma vida cheia de significado e realiza&ccedil;&otilde;es! Esse treinamento ir&aacute; capacit&aacute;-lo com a compreens&atilde;o que voc&ecirc; precisa para implementar os conceitos ensinados para que voc&ecirc; possa atingir qualquer objetivo que voc&ecirc; realmente deseja.</p>\r\n<p style=\"text-align: justify;\">Como funciona o programa de coaching<strong> MENTE EMPREENDEDORA?</strong></p>\r\n<p style=\"text-align: justify;\">O Programa de Coaching MENTE EMPREENDEDORA &eacute; um treinamento interativo de 09 meses projetado para ajud&aacute;-lo a entender e aplicar os princ&iacute;pios e conceitos que o levar&aacute; a descobrir o prop&oacute;sito de sua vida, seus sonhos e a desenvolver e maximizar as capacidades necess&aacute;rias para o sucesso. Com a aplica&ccedil;&atilde;o rigorosa em praticar esses princ&iacute;pios, voc&ecirc; experimentar&aacute; resultados incr&iacute;veis em todas as &aacute;reas de sua vida.</p>\r\n<p style=\"text-align: justify;\">Ao longo do treinamento voc&ecirc; conseguir&aacute; identificar os pensamentos do fracasso (h&aacute;bitos e cren&ccedil;as) que est&atilde;o impedindo voc&ecirc; de alcan&ccedil;ar os resultados que realmente deseja, em todas as &aacute;reas da sua vida. Aprender&aacute; a desenvolver pensamentos e atitudes que o conduzir&aacute; a subir os degraus do sucesso.</p>\r\n<p style=\"text-align: justify;\">N&oacute;s nos concentramos nas principais metas e objetivos que voc&ecirc; deseja alcan&ccedil;ar. Defina uma meta que seja digna de voc&ecirc; e n&oacute;s o orientaremos para sua realiza&ccedil;&atilde;o.</p>\r\n<p style=\"text-align: justify;\">Esse treinamento &eacute; uma combina&ccedil;&atilde;o estrategicamente projetada de educa&ccedil;&atilde;o, responsabilidade e a&ccedil;&atilde;o. A&ccedil;&atilde;o para a realiza&ccedil;&atilde;o progressiva de seus sonhos.</p>\r\n<p style=\"text-align: justify;\">Pensamos em tudo o que voc&ecirc; precisa para se concentrar no que realmente importa: o seu sucesso!</p>\r\n<p>&nbsp;</p>', '2019-05-06', '2019-05-31', '<p>O que esperar do treinamento MENTE EMPREENDEDORA</p>', '_parent', 1, NULL, '0', NULL, 1, 3, 3, '2019-05-06 21:52:34', '2019-05-20 01:29:40'),
(6, 'Dores nas costas', 'dores-nas-costas', '1558401370.jpg', '<p><img src=\"http://127.0.0.1:8000/uploads/source/treinamentos/Imagem3.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<p style=\"text-align: center;\">O que esperar do treinamento DORES NAS COSTAS NUNCA!</p>\r\n<p style=\"text-align: center;\"><img src=\"http://127.0.0.1:8000/uploads/source/treinamentos/IMAGEM%20DORES%20NAS%20COSTAS.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<p style=\"text-align: justify;\">Como &eacute; bom sentir o al&iacute;vio das dores cr&ocirc;nicas ap&oacute;s algum&nbsp; procedimento! Melhor ainda &eacute; saber que o al&iacute;vio &eacute; permanente ap&oacute;s fazer uma terapia que que resolveu o problema na sua causa principal.</p>\r\n<p style=\"text-align: justify;\">Muitos s&atilde;o os fatores que desencadeiam as dores cr&ocirc;nicas. Alguns desses fatores s&atilde;o:</p>\r\n<ul>\r\n<li style=\"text-align: justify;\">sedentarismo,</li>\r\n<li style=\"text-align: justify;\">sobrepeso,</li>\r\n<li style=\"text-align: justify;\">falta de atividade f&iacute;sica,</li>\r\n<li style=\"text-align: justify;\">posturas incorretas nas atividades di&aacute;rias,</li>\r\n<li style=\"text-align: justify;\">&nbsp;tens&otilde;es e encurtamentos musculares,</li>\r\n<li style=\"text-align: justify;\">h&eacute;rnia discal,</li>\r\n<li style=\"text-align: justify;\">artrose,</li>\r\n<li style=\"text-align: justify;\">idosos,</li>\r\n<li style=\"text-align: justify;\">gravidez e outros problemas org&acirc;nicos sist&ecirc;micos.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\"><strong>&Eacute; importante enfatizar que:</strong></p>\r\n<p style=\"text-align: justify;\">as diferentes&nbsp;<strong>posturas</strong>&nbsp;adotadas no dia a dia e durante as atividades quotidianas, o sedentarismo e o estresse est&atilde;o entre as principais causas de dores cr&ocirc;nicas. Principalmente sobre essas causas o treinamento terap&ecirc;utico Dores nas Costas Nunca Mais ser&aacute; um divisor de &aacute;guas, em se tratando de resolu&ccedil;&atilde;o prolonga das dores cr&ocirc;nicas.</p>\r\n<p style=\"text-align: justify;\">Nesse treinamento voc&ecirc; aprender&aacute; como reconhecer as poss&iacute;veis raz&otilde;es de dores nas costas, como avaliar e, ap&oacute;s reconhecimento das poss&iacute;veis causas, como desenvolver o programa terap&ecirc;utico sugerido para sua melhora cl&iacute;nica. Voc&ecirc; tamb&eacute;m ter&aacute; o suporte especializado que o direcionar&aacute; a fazer uma avalia&ccedil;&atilde;o e terap&ecirc;utica mais efetiva.</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; tem &agrave; sua disposi&ccedil;&atilde;o a oportunidade de se beneficiar de um programa terap&ecirc;utico efetivo para suas dores cr&ocirc;nicas.</p>\r\n<p style=\"text-align: justify;\">Tome a decis&atilde;o correta, inscreva-se e comece j&aacute; o seu treinamento para uma vida mais feliz e sem dor.</p>', '2019-05-06', '2019-05-31', '<p>O que esperar do treinamento DORES NAS COSTAS NUNCA!</p>', '_parent', 1, NULL, '0', 'Eber Ortiz', 2, 3, 3, '2019-05-06 22:05:40', '2019-05-21 04:16:10'),
(7, 'Projeto 3', 'projeto-3', '1557174544.jpg', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema.&nbsp;<a title=\"Resumo\" href=\"https://codex.wordpress.org/pt-br:Resumo\" target=\"_blank\" rel=\"noopener\">Aprenda mais sobre resumos manuais.</a></p>', '2019-05-06', '2019-05-31', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema.&nbsp;<a title=\"Resumo\" href=\"https://codex.wordpress.org/pt-br:Resumo\" target=\"_blank\" rel=\"noopener\">Aprenda mais sobre resumos manuais.</a></p>', '_parent', 1, NULL, '0', 'Eber', 3, 3, 3, '2019-05-06 23:29:04', '2019-05-06 23:29:04'),
(8, 'Projeto 4', 'projeto-4', '1558403081.png', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema.&nbsp;</p>', '2019-05-06', '2019-05-25', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema. ....</p>', '_parent', 1, NULL, '0', NULL, 4, 4, 3, '2019-05-06 23:29:36', '2019-05-21 04:44:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(2, 'moderador', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(3, 'super-admin', 'web', '2019-05-06 14:54:18', '2019-05-06 14:54:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 2),
(1, 3),
(2, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 2),
(3, 3),
(4, 2),
(4, 3),
(5, 3),
(6, 3),
(7, 3),
(8, 3),
(9, 3),
(10, 3),
(11, 3),
(12, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sales`
--

CREATE TABLE `sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `transaction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('started','approved','canceled','pending_analysis','billet_printed','refunded','dispute','completed','blocked','chargeback','delayed','expired') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sales`
--

INSERT INTO `sales` (`id`, `user_id`, `course_id`, `transaction`, `status`, `date`, `created_at`, `updated_at`) VALUES
(1, 2, 1, NULL, NULL, NULL, '2019-05-06 14:54:20', '2019-05-06 14:54:20'),
(2, 2, 2, NULL, NULL, NULL, '2019-05-06 14:54:20', '2019-05-06 14:54:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sections`
--

CREATE TABLE `sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sections`
--

INSERT INTO `sections` (`id`, `name`, `slug`, `enabled`, `created_at`, `updated_at`) VALUES
(1, 'Global menu', 'global-menu', 1, '2019-05-06 16:55:09', '2019-05-06 16:55:09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trainees`
--

CREATE TABLE `trainees` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marital_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `some_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `have_job` tinyint(1) DEFAULT NULL,
  `office` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `career_id` int(10) UNSIGNED NOT NULL,
  `period_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `universities`
--

CREATE TABLE `universities` (
  `id` int(10) UNSIGNED NOT NULL,
  `initials` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'editor@gmail.com', '$2y$10$c.UpKG.87Xy231BKAXUk.ukYkzNDZ6M1KVO7WF3La1zECltSJQgqu', NULL, '2019-05-06 14:54:19', '2019-05-06 14:54:19'),
(2, 'moderador', 'moderador@gmail.com', '$2y$10$bNjg8XZ2fyyE8biZBWkwIetMoLiYclVy0XjGTfrxsrdxGX.FAmt5S', NULL, '2019-05-06 14:54:19', '2019-05-06 14:54:19'),
(3, 'admin', 'admin@gmail.com', '$2y$10$QWfWCWZfz86HueIidWGJJO1YNg2FhrM4rN5.E4gQOy4rcuEjIItC2', NULL, '2019-05-06 14:54:19', '2019-05-06 14:54:19');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignments_user_id_foreign` (`user_id`),
  ADD KEY `assignments_classroom_id_foreign` (`classroom_id`);

--
-- Indices de la tabla `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `careers_university_id_foreign` (`university_id`);

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indices de la tabla `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classrooms_module_id_foreign` (`module_id`);

--
-- Indices de la tabla `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `courses_url_unique` (`url`),
  ADD UNIQUE KEY `courses_code_unique` (`code`),
  ADD KEY `courses_user_id_foreign` (`user_id`),
  ADD KEY `courses_category_id_foreign` (`category_id`);

--
-- Indices de la tabla `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_foreign` (`menu`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indices de la tabla `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indices de la tabla `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modules_course_id_foreign` (`course_id`);

--
-- Indices de la tabla `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`),
  ADD KEY `pages_section_id_foreign` (`section_id`),
  ADD KEY `pages_user_id_foreign` (`user_id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `periods`
--
ALTER TABLE `periods`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_category_id_foreign` (`category_id`),
  ADD KEY `posts_user_id_foreign` (`user_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indices de la tabla `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_user_id_foreign` (`user_id`),
  ADD KEY `sales_course_id_foreign` (`course_id`);

--
-- Indices de la tabla `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sections_slug_unique` (`slug`);

--
-- Indices de la tabla `trainees`
--
ALTER TABLE `trainees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainees_user_id_foreign` (`user_id`),
  ADD KEY `trainees_career_id_foreign` (`career_id`),
  ADD KEY `trainees_period_id_foreign` (`period_id`);

--
-- Indices de la tabla `universities`
--
ALTER TABLE `universities`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `careers`
--
ALTER TABLE `careers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `classrooms`
--
ALTER TABLE `classrooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de la tabla `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `periods`
--
ALTER TABLE `periods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `trainees`
--
ALTER TABLE `trainees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `universities`
--
ALTER TABLE `universities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `assignments_classroom_id_foreign` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`),
  ADD CONSTRAINT `assignments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `careers`
--
ALTER TABLE `careers`
  ADD CONSTRAINT `careers_university_id_foreign` FOREIGN KEY (`university_id`) REFERENCES `universities` (`id`);

--
-- Filtros para la tabla `classrooms`
--
ALTER TABLE `classrooms`
  ADD CONSTRAINT `classrooms_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `courses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_foreign` FOREIGN KEY (`menu`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Filtros para la tabla `pages`
--
ALTER TABLE `pages`
  ADD CONSTRAINT `pages_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  ADD CONSTRAINT `pages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `trainees`
--
ALTER TABLE `trainees`
  ADD CONSTRAINT `trainees_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`),
  ADD CONSTRAINT `trainees_period_id_foreign` FOREIGN KEY (`period_id`) REFERENCES `periods` (`id`),
  ADD CONSTRAINT `trainees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
