-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 04-Ago-2020 às 14:29
-- Versão do servidor: 5.7.23-23
-- versão do PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `prosau76_psiv2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `assignments`
--

CREATE TABLE `assignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `classroom_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `assignments`
--

INSERT INTO `assignments` (`id`, `user_id`, `classroom_id`, `created_at`, `updated_at`) VALUES
(1, 6, 2, '2020-07-21 23:32:11', '2020-07-21 23:32:11'),
(2, 6, 3, '2020-07-21 23:32:11', '2020-07-21 23:32:11'),
(3, 6, 4, '2020-07-21 23:32:11', '2020-07-21 23:32:11'),
(4, 6, 5, '2020-07-21 23:32:11', '2020-07-21 23:32:11'),
(5, 6, 6, '2020-07-21 23:32:11', '2020-07-21 23:32:11'),
(6, 6, 7, '2020-07-21 23:32:11', '2020-07-21 23:32:11');

-- --------------------------------------------------------

--
-- Estrutura da tabela `careers`
--

CREATE TABLE `careers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `university_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `section`, `enabled`, `created_at`, `updated_at`) VALUES
(2, 'Destaque', 'destaque', 'page', 1, '2019-05-06 19:59:03', '2019-05-06 19:59:03'),
(3, 'Treinamentos', 'treinamentos', 'page', 1, '2019-05-06 20:57:01', '2019-06-25 18:19:34'),
(4, 'Palestras', 'palestras', 'page', 1, '2019-05-06 20:57:13', '2019-05-06 20:57:13'),
(5, 'Programas', 'programas', 'page', 1, '2019-06-07 05:19:55', '2019-06-07 05:19:55'),
(6, 'Consultorias', 'consultorias', 'page', 1, '2019-06-17 02:38:27', '2019-06-17 02:38:27'),
(7, 'Especialidades', 'especialidades', 'page', 1, '2019-06-17 02:39:10', '2019-06-17 02:39:10'),
(8, 'Produtos', 'produtos', 'page', 1, '2019-06-25 21:55:30', '2019-06-25 21:55:30'),
(9, 'Cursos e Treinamentos', 'cursos-e-treinamentos', 'course', 1, '2019-12-02 14:31:53', '2019-12-02 14:31:53');

-- --------------------------------------------------------

--
-- Estrutura da tabela `classrooms`
--

CREATE TABLE `classrooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `module_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `classrooms`
--

INSERT INTO `classrooms` (`id`, `name`, `description`, `video`, `file`, `views`, `status`, `module_id`, `created_at`, `updated_at`) VALUES
(2, 'Orientações gerais', 'Exercícios de reajustes articulares', 'https://vimeo.com/437621403', NULL, NULL, 1, 5, '2020-07-21 23:11:35', '2020-07-22 00:09:50'),
(3, 'Dores crônicas', 'Exercícios de reajustes articulares', 'https://vimeo.com/437623699', NULL, NULL, 1, 5, '2020-07-21 23:15:55', '2020-07-22 23:44:55'),
(4, 'flexão de quadril / exercício 1', 'Exercícios de reajustes articulares', 'https://vimeo.com/437625357', NULL, NULL, 1, 5, '2020-07-21 23:16:37', '2020-07-23 00:14:47'),
(5, 'Reajuste pelvico / exercicio 2', 'Exercícios de reajustes articulares', 'https://vimeo.com/437637258', NULL, NULL, 1, 5, '2020-07-21 23:17:22', '2020-07-23 00:15:58'),
(6, 'Reajuste pélvico com bola e cinto / exercicio3', 'Exercícios de reajustes articulares', 'https://vimeo.com/437627401', NULL, NULL, 1, 5, '2020-07-21 23:18:22', '2020-07-23 00:17:27'),
(7, 'Reajuste pelvico com flexao joelho / exercício 6', 'Reajustes articulares', 'https://vimeo.com/437872689', NULL, NULL, 1, 5, '2020-07-21 23:20:53', '2020-07-23 02:19:20'),
(8, 'Rotação lombar / exercício 5', NULL, 'https://vimeo.com/437874508', NULL, NULL, 1, 5, '2020-07-23 02:15:50', '2020-07-23 02:15:50'),
(9, 'Rotacao lombar avançado / exercício 4', 'Reajustes articulares', 'https://vimeo.com/437876406', NULL, NULL, 1, 5, '2020-07-23 02:16:57', '2020-07-23 02:16:57'),
(10, 'Tração lombar / exercício 7', 'Reajustes articulares', 'https://vimeo.com/437978666', NULL, NULL, 1, 5, '2020-07-23 02:19:04', '2020-07-23 02:19:04'),
(11, 'Tração cervical com apoio de antebraço / exercício 8', 'Reajustes articulares', 'https://vimeo.com/439048517', NULL, NULL, 1, 5, '2020-07-23 02:20:34', '2020-07-23 02:20:34'),
(12, 'Tração cervical / exercício 9', 'Reajustes articulares', 'https://vimeo.com/439061377', NULL, NULL, 1, 5, '2020-07-23 02:21:45', '2020-07-23 02:21:45'),
(13, 'Baixar livro postura e dor', NULL, NULL, 'https://prosaudeintegral.com.br/uploads/source/treinamentos/MANUAL%20POSTURA%20E%20DOR.pdf', NULL, 1, 7, '2020-07-23 03:10:02', '2020-07-23 03:10:02'),
(14, 'Um corpo com poder regenerativo', NULL, 'https://vimeo.com/439426640/169dcb49d2', NULL, NULL, 1, 7, '2020-07-23 03:11:06', '2020-07-23 03:16:04'),
(15, 'Nutrição antiinflamatoria', NULL, NULL, 'https://prosaudeintegral.com.br/uploads/source/treinamentos/NUTRIC%CC%A7A%CC%83O%20ANTIINFLAMATO%CC%81RIA.pdf', NULL, 1, 7, '2020-07-23 03:12:28', '2020-07-23 03:12:28');

-- --------------------------------------------------------

--
-- Estrutura da tabela `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `total_hours` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `free` tinyint(1) NOT NULL DEFAULT '0',
  `price` double(10,2) DEFAULT NULL,
  `price_old` double(10,2) DEFAULT NULL,
  `price_plots` double(10,2) DEFAULT NULL,
  `total_plots` int(11) DEFAULT NULL,
  `link_buy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `courses`
--

INSERT INTO `courses` (`id`, `name`, `url`, `description`, `image`, `video`, `code`, `total_hours`, `published`, `free`, `price`, `price_old`, `price_plots`, `total_plots`, `link_buy`, `status`, `user_id`, `category_id`, `created_at`, `updated_at`) VALUES
(3, 'Asma princípios preventivos', 'asma-principios-preventivos', '<p style=\"text-align: justify;\">ASMA &eacute; uma doen&ccedil;a respirat&oacute;ria caracterizada por recorrentes crises em que as vias a&eacute;reas se estreitam e inflamam, provocando falta de ar, chiado no peito e tosse. As crises geralmente est&atilde;o relacionadas a algum fator alerg&ecirc;nico.</p>\r\n<p style=\"text-align: justify;\">Tr&ecirc;s fatores est&atilde;o presentes durante ocorr&ecirc;ncia de crises asm&aacute;ticas:</p>\r\n<div class=\"box-grey\" style=\"text-align: justify;\">\r\n<p><strong>Inflamacao dos br&ocirc;nquios</strong></p>\r\n<p><strong>Muita produ&ccedil;&atilde;o de muco</strong></p>\r\n<p><strong>Broncoconstric&atilde;o</strong></p>\r\n</div>\r\n<p style=\"text-align: justify;\">Essa tr&iacute;ade faz perpetuar um ciclo vicioso:</p>\r\n<div class=\"box-grey\" style=\"text-align: justify;\">\r\n<p><strong>Crises</strong></p>\r\n<p><strong>Bombinha</strong></p>\r\n<p><strong>emerg&ecirc;ncia</strong></p>\r\n</div>\r\n<p style=\"text-align: justify;\">Ao pensarmos em princ&iacute;pios preventivos, devemos pensar em fatores causais prim&aacute;rios de uma condi&ccedil;&atilde;o corporal que propicia ou favorece as crises asm&aacute;ticas.</p>\r\n<p style=\"text-align: justify;\">Reconhecer as causas primarias e se dispor a mudan&ccedil;a de h&aacute;bitos, promover&aacute; melhora das crises e colocar&aacute; o corpo em uma condi&ccedil;&atilde;o de melhora da tr&iacute;ade do mal asm&aacute;tico &ndash; <strong>condi&ccedil;&atilde;o essencial para diminuir as recidivas de novas crises asm&aacute;ticas e, por fim, viver sem crises</strong>.</p>\r\n<p style=\"text-align: justify;\">O programa terap&ecirc;utico proposto visa ajud&aacute;-lo em momentos de crises, bem como preparar e fortalecer seu organismo como medida preventiva a novas crises. O programa terap&ecirc;utico promove tamb&eacute;m resultados sobre rinite e sinusite. Se voc&ecirc; seguir sistematicamente esses princ&iacute;pios tamb&eacute;m poder&aacute; se beneficiar com a melhora de muitos outros problemas de sa&uacute;de.</p>', 'asma-princípios-preventivos.jpeg', NULL, NULL, '00:00', 1, 1, 0.00, 0.00, NULL, NULL, '#', 1, 3, 9, '2019-12-02 15:14:11', '2019-12-02 15:14:11'),
(4, 'Detox fígado', 'detox-figado', '<h1 style=\"text-align: left;\">Por qu&ecirc; Desintoxicar o F&iacute;gado?</h1>\r\n<p style=\"text-align: justify;\">Com o tempo, os res&iacute;duos de alimentos e bebidas n&atilde;o saud&aacute;veis, como os embutidos, alco&oacute;licos e outros ricos em conservantes e aditivos qu&iacute;micos, v&atilde;o ficando acumulados no f&iacute;gado, causando sua inflama&ccedil;&atilde;o e dificultando o seu funcionamento.</p>\r\n<p style=\"text-align: justify;\">&Eacute; por isso que &eacute; t&atilde;o importante fazer essa limpeza e, de prefer&ecirc;ncia, manter uma rotina mais saud&aacute;vel para evitar um novo ac&uacute;mulo de toxinas. Ao fazer isso, todos os &oacute;rg&atilde;os do corpo passam a funcionar melhor, beneficiando a sa&uacute;de de modo geral.</p>\r\n<p style=\"text-align: justify;\">O nosso f&iacute;gado &eacute; muito&nbsp;<strong>bem relacionado </strong>com os outros &oacute;rg&atilde;os de nosso corpo. Ele &eacute; um dos cinco&nbsp;<strong>&oacute;rg&atilde;os vitais</strong>&nbsp;que possu&iacute;mos e, para dar conta de seu trabalho, interage continuamente com os demais. Dentre sueus principais trabalhos, constam: a&nbsp;<strong>filtragem do sangue, </strong><strong>eliminar toxinas</strong> do organismo e tamb&eacute;m atua no sentido de&nbsp;<strong>reconhecer a presen&ccedil;a de subst&acirc;ncias t&oacute;xicas no sangue</strong>&nbsp;&ndash; como drogas, venenos, &aacute;lcool &ndash; para, a seguir,&nbsp;<strong>cataboliz&aacute;-las</strong>, isto &eacute;, quebr&aacute;-las em mol&eacute;culas menores, que poder&atilde;o permanecer armazenadas no pr&oacute;prio f&iacute;gado ou ser excretadas pelos rins, pele ou pulm&otilde;es.</p>\r\n<p style=\"text-align: justify;\">Na ves&iacute;cula, a&nbsp;<strong>bile produzida pelo f&iacute;gado</strong>&nbsp;&eacute; armazenada at&eacute; que o intestino precise dela para&nbsp;<strong>digerir as gorduras</strong>&nbsp;e absorver adequadamente as vitaminas A, D, E e K.</p>\r\n<p style=\"text-align: justify;\">Devido a m&uacute;ltiplos fatores de h&aacute;bitos e estilo de vida, o f&iacute;gado pode ser&nbsp;<strong>danificado, n&atilde;o desenvolvendo suas fun&ccedil;&otilde;es de filtragem e purific&ccedil;&atilde;o do corpo.</strong> <strong>Limpar o f&iacute;gado &eacute; uma parte importante</strong>&nbsp;da aten&ccedil;&atilde;o &agrave; sa&uacute;de para equilibrar as fun&ccedil;&otilde;es naturais do corpo.</p>\r\n<h1 style=\"text-align: left;\">Desintoxica&ccedil;&atilde;o do f&iacute;gado</h1>\r\n<p style=\"text-align: justify;\">O f&iacute;gado &eacute; uma verdadeira ind&uacute;stria, dividida em v&aacute;rios departamentos, cada um deles produzindo materiais espec&iacute;ficos para fun&ccedil;&otilde;es determinadas.</p>\r\n<p style=\"text-align: justify;\">Algumas das fun&ccedil;&otilde;es atribu&iacute;das ao f&iacute;gado incluem:</p>\r\n<div class=\"box-grey\">\r\n<ul style=\"text-align: justify;\">\r\n<li>processar os nutrientes absorvidos pelo intestino;</li>\r\n<li>regular o equil&iacute;brio de gorduras, a&ccedil;&uacute;cares e prote&iacute;nas no sangue;</li>\r\n<li>estimular a coagula&ccedil;&atilde;o correta do sangue, produ&ccedil;&atilde;o de colesterol e prote&iacute;nas essenciais;</li>\r\n<li>armazenamento de minerais importantes para o organismo, al&eacute;m de vitamina A;</li>\r\n<li>remover toxinas da corrente sangu&iacute;nea;</li>\r\n<li>destrui&ccedil;&atilde;o dos gl&oacute;bulos vermelhos velhos;</li>\r\n<li>metabolizar &aacute;lcool, medicamentos e outras drogas.</li>\r\n<li>&nbsp;</li>\r\n</ul>\r\n</div>\r\n<h2 style=\"text-align: left;\"><strong>Como saber quando preciso de uma desintoxica&ccedil;&atilde;o?</strong></h2>\r\n<p style=\"text-align: justify;\">N&atilde;o &eacute; dif&iacute;cil descobrir. Primeiramente, observe os sintomas:</p>\r\n<div class=\"box-grey\">\r\n<ul style=\"text-align: justify;\">\r\n<li>voc&ecirc; tem ac&uacute;mulo de gordura e dores no abd&ocirc;men?</li>\r\n<li>est&aacute; ganhando muito peso ou tendo dificuldades para perder?</li>\r\n<li>sente cansa&ccedil;o excessivo sem motivo aparente?</li>\r\n<li>tem sentido que seu apetite n&atilde;o &eacute; mais o mesmo?</li>\r\n<li>sofre com azia e dificuldade de digerir alimentos gordurosos?</li>\r\n</ul>\r\n</div>\r\n<p style=\"text-align: justify;\">Um f&iacute;gado saud&aacute;vel garante um corpo saud&aacute;vel e longevo.</p>\r\n<p style=\"text-align: center;\"><strong>Passe por essa experi&ecirc;ncia agora mesmo e sinta os benef&iacute;cios em seu corpo. <br /></strong><strong>Sua sa&uacute;de agradece.</strong></p>', 'detox-fígado.jpeg', NULL, NULL, '00:00', 1, 1, 0.00, 0.00, NULL, NULL, '#', 1, 3, 9, '2019-12-02 17:05:26', '2019-12-02 17:05:26'),
(5, 'Diabetes', 'diabetes', '<p style=\"text-align: justify;\"><strong>Princ&iacute;pios naturais de cura</strong></p>\r\n<p style=\"text-align: justify;\">Em pleno s&eacute;culo XXI a cren&ccedil;a dominante &eacute; que, uma vez com diabetes, n&atilde;o h&aacute; possibilidade de cura. Em algum momento voc&ecirc; provavelmente j&aacute; ouviu falar que o diabetes n&atilde;o tem cura, apenas as possibilidades de uma variedade de complica&ccedil;&otilde;es. Este &eacute; um sistema de cren&ccedil;a antigo apoiado por muitos profissionais m&eacute;dicos e farmac&ecirc;uticos que mascaram esta doen&ccedil;a.</p>\r\n<p style=\"text-align: justify;\">No entanto, s&atilde;o in&uacute;meros os testemunhos que testificam a possibilidade de <strong>reverter completamente o diabetes tipo 2</strong>&nbsp;naturalmente. &ldquo;Tudo o que &eacute; necess&aacute;rio &eacute; deixar de lado nossa cren&ccedil;a de que o diabetes n&atilde;o pode ser revertido, ent&atilde;o estamos livres para cultivar a compreens&atilde;o do que &eacute; poss&iacute;vel&rdquo;, Dr. Gabriel Cousens.</p>\r\n<p style=\"text-align: justify;\">&ldquo;Fazer um estudo com mais de 120 diab&eacute;ticos na &Aacute;rvore da Vida proporcionou-me uma vis&atilde;o mais profunda do que agora chamo de &ldquo;s&iacute;ndrome degenerativa cr&ocirc;nica do diabetes&rdquo; (CDDS). Minha experi&ecirc;ncia cl&iacute;nica com essas 120 pessoas &eacute; que o diabetes tipo 2 &eacute; uma doen&ccedil;a cur&aacute;vel.&rdquo;</p>\r\n<div class=\"box-gray\">\r\n<p style=\"text-align: justify;\"><em>* Cura significa um a&ccedil;&uacute;car no sangue em jejum (FBS) inferior a 100 e sem medica&ccedil;&atilde;o.<br /><br /></em></p>\r\n</div>\r\n<p style=\"text-align: justify;\"><strong>Como este milagre &eacute; realizado?</strong>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Sim, esse milagre &eacute; poss&iacute;vel!</p>\r\n<p style=\"text-align: justify;\">Atrav&eacute;s de um conjunto de mudan&ccedil;as no estilo de vida, h&aacute;bitos alimentares e desintoxica&ccedil;&atilde;o org&acirc;nica seu corpo poder&aacute; reagir e evoluir com baixos &iacute;ndices glic&ecirc;micos, sem aux&iacute;lio de medicamentos.&nbsp; &nbsp;</p>\r\n<p style=\"text-align: justify;\"><strong>&nbsp;</strong></p>\r\n<p style=\"text-align: center;\"><strong>Passe por essa experi&ecirc;ncia agora mesmo e sinta os benef&iacute;cios em seu corpo. <br /></strong><strong>Sua sa&uacute;de agradece.</strong></p>', 'diabetes.jpeg', NULL, NULL, NULL, 1, 1, 0.00, 0.00, NULL, NULL, NULL, 1, 3, 9, '2019-12-02 17:11:12', '2019-12-02 17:11:32'),
(6, 'Gastrite', 'gastrite', '<p>Content</p>', 'gastrite.jpeg', NULL, NULL, '00:00', 1, 1, 0.00, 0.00, NULL, NULL, '#', 1, 3, 9, '2019-12-02 17:15:26', '2019-12-02 17:15:26'),
(7, 'Lavagem intestinal', 'lavagem-intestinal', '<p>Content</p>', 'lavagem-intestinal.jpeg', NULL, NULL, '00:00', 1, 1, 0.00, 0.00, NULL, NULL, '#', 1, 3, 9, '2019-12-02 17:16:27', '2019-12-02 17:16:27'),
(8, 'Semana detox', 'semana-detox', '<p>Content</p>', 'semana-detox.jpeg', NULL, NULL, '00:00', 1, 1, 0.00, 0.00, NULL, NULL, '#', 1, 3, 9, '2019-12-02 17:20:57', '2019-12-02 17:20:57'),
(9, 'Sucesso em dose dupla', 'sucesso-em-dose-dupla', '<p>Sucesso na fam&iacute;lia, no trabalho e na vida. Todos ansiamos pelo reconhecimento do nosso valor! A maioria das pessoas sente que sua vida poderia ser mais, que est&aacute; faltado algo e, por isso, n&atilde;o est&aacute; conseguindo os resultados esperados. Anseia por deixar sua marca no mundo e tem o desejo de fazer a diferen&ccedil;a atrav&eacute;s de uma vida com prop&oacute;sito.</p>\r\n<p>Mas, esse parece ser o problema na vida maioria das pessoas, pois uma vida sem prop&oacute;sitos definidos, claros, o levar&aacute; lugar algum. Voc&ecirc; sempre estar&aacute; insatisfeito com o patr&atilde;o, com os colegas de equipe, com a fam&iacute;lia....</p>\r\n<p>Voc&ecirc; sente bem l&aacute; dentro como se estivesse faltando algo, uma pe&ccedil;a chave para viver uma vida mais m&aacute;gica, repleta de motiva&ccedil;&atilde;o e entusiasmo. Voc&ecirc; v&ecirc; que o mundo est&aacute; avan&ccedil;ando e que voc&ecirc; est&aacute; ficando para tr&aacute;s.</p>\r\n<p>O empres&aacute;rio observa que sua equipe n&atilde;o est&aacute; produtiva e que algo est&aacute; faltando. <strong>O que &eacute; necess&aacute;rio para motiv&aacute;-los a resultados mais satisfat&oacute;rios?</strong></p>\r\n<p>Pergunto: Voc&ecirc; quer sentir-se como v&iacute;tima das circunstancias ou quer avan&ccedil;ar com o mundo, criando as circunst&acirc;ncias para o seu sucesso, sendo uma inspira&ccedil;&atilde;o para sua equipe? Ent&atilde;o,&nbsp;<strong>viva com prop&oacute;sito! Tenha prop&oacute;sitos definidos.</strong>&nbsp;Tenha um sonho em mente e realize-o em sua vida!</p>\r\n<p>&ldquo;As pessoas de maior resultado t&ecirc;m um forte prop&oacute;sito por tr&aacute;s de cada a&ccedil;&atilde;o em sua vida&rdquo;</p>\r\n<p>Todos os <strong>vision&aacute;rios </strong>s&atilde;o movidos por um prop&oacute;sito definido em suas vidas.</p>\r\n<h5><strong><u>o prop&oacute;sito &eacute; a chave para a transforma&ccedil;&atilde;o</u></strong><strong>.</strong></h5>\r\n<p>O estudo acad&ecirc;mico te d&aacute; um conhecimento valioso, mas nunca te ensinou a pensar para o sucesso. Em casa, no trabalho e no meio de conviv&ecirc;ncia, voc&ecirc; n&atilde;o foi ensinado nem estimulado sobre prop&oacute;sito de vida e estrat&eacute;gias para ser uma pessoa de sucesso. Isso culmina com confus&atilde;o, frustra&ccedil;&atilde;o e fracasso. Por isso muitos n&atilde;o conseguem ser bem sucedidos na vida.</p>\r\n<p>Se voc&ecirc; &eacute; uma pessoa que:</p>\r\n<div class=\"box-grey\">\r\n<ul>\r\n<li>Gostaria de alterar radicalmente pelo menos uma &aacute;rea de sua vida.</li>\r\n<li>J&aacute; tentou fazer isso antes, mas n&atilde;o obteve os resultados desejados.</li>\r\n<li>N&atilde;o est&aacute; pronto para desistir de uma vida mais feliz e mais gratificante.</li>\r\n<li>Est&aacute; insatisfeito com sua situa&ccedil;&atilde;o atual e deseja mudar, mas n&atilde;o sabe como.</li>\r\n<li>Tem um sonho (conseguir algo ou ser algo) que deseja realizar.</li>\r\n<li>Se considera incapaz.</li>\r\n<li>Quer ser bem sucedido na vida.</li>\r\n</ul>\r\n</div>\r\n<p><strong>Atrav&eacute;s desse treinamento voc&ecirc; ir&aacute; transformar todos os seus conceitos e vis&atilde;o de mundo.</strong></p>\r\n<p>Se voc&ecirc; acha que vai chegar onde quer por acaso, pense novamente.&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p style=\"text-align: center;\"><strong>O&nbsp;sucesso&nbsp;n&atilde;o ocorre por acaso!</strong></p>\r\n<p>O empres&aacute;rio observa que sua equipe n&atilde;o est&aacute; produtiva e que algo est&aacute; faltando. <strong>O que &eacute; necess&aacute;rio para motiv&aacute;-los a resultados mais satisfat&oacute;rios?</strong></p>\r\n<p>Atrav&eacute;s de um prop&oacute;sito definido e planos estrat&eacute;gicos bem elaborados voc&ecirc; adquirir&aacute; a autoconfian&ccedil;a e determina&ccedil;&atilde;o para <strong>mudar os rumos de sua empresa</strong>.</p>\r\n<p>Com o treinamento&nbsp;<strong>SUCESSO EM DOSE DUPLA</strong> <strong>&ndash; </strong><strong>O Segredo para a Realiza&ccedil;&atilde;o Pessoal e Profissional</strong>, voc&ecirc; ir&aacute; desvendar os segredos do potencial humano e do sucesso pessoal e profissional.</p>\r\n<p>Esse treinamento &eacute; uma <strong>combina&ccedil;&atilde;o estrategicamente projetada de educa&ccedil;&atilde;o, responsabilidade e a&ccedil;&atilde;o.</strong> A&ccedil;&atilde;o para a realiza&ccedil;&atilde;o progressiva de seus sonhos.</p>\r\n<p>Pensamos em tudo o que voc&ecirc; precisa para se concentrar no que realmente importa: <strong>o seu sucesso!</strong></p>\r\n<p style=\"text-align: center;\"><strong>Passe por essa experi&ecirc;ncia de </strong><strong>SUCESSO</strong><strong> agora mesmo e sua vida e conceitos n&atilde;o ser&atilde;o mais os mesmos. </strong></p>', 'sucesso-em-dose-duplas.jpeg', NULL, NULL, '00:00', 1, 1, 0.00, 0.00, NULL, NULL, '#', 1, 3, 9, '2019-12-02 17:31:10', '2019-12-03 23:57:06'),
(10, '+ Visão – olhos sempre saudáveis', 'visao-olhos-sempre-saudaveis', '<p style=\"text-align: justify;\">A vida moderna estressante e cheia de facilidades, traz consigo muitos componentes danosos aos olhos. O excesso de prote&ccedil;&atilde;o contra a luz solar, o uso indiscriminado do computador e eletr&ocirc;nicos, passar o dia&nbsp;quase exclusivamente em ambientes fechados sob luz artificial, a falta do olhar &agrave; dist&acirc;ncia e o meio estressante em&nbsp;que vivemos, sedentarismo e alimentos inadequados s&atilde;o fatores nocivos a uma boa vis&atilde;o.</p>\r\n<p style=\"text-align: justify;\">A melhora ou recupera&ccedil;&atilde;o natural da vis&atilde;o s&oacute; ser&aacute; poss&iacute;vel a partir da observ&acirc;ncia de alguns princ&iacute;pios, tais como:</p>\r\n<div class=\"box-grey\">\r\n<ul style=\"text-align: justify;\">\r\n<li>do ajuste da vis&atilde;o a diferentes intensidades&nbsp;de luz;</li>\r\n<li>do equil&iacute;brio do uso dos dois olhos, ativando m&uacute;sculos pouco utilizados em nossos movimentos;</li>\r\n<li>do fortalecimento do sistema nervoso e est&iacute;mulo de conex&otilde;es e transmiss&atilde;o de impulsos&nbsp;neurais;</li>\r\n<li>do olhar &agrave; dist&acirc;ncia;</li>\r\n<li>da igualdade&nbsp;de uso da vis&atilde;o central e perif&eacute;rica e, especialmente, do relaxamento de todo o sistema visual.</li>\r\n</ul>\r\n</div>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Observar pequenos detalhes tamb&eacute;m &eacute; de suma import&acirc;ncia, tais como:</p>\r\n<div class=\"box-grey\">\r\n<ul style=\"text-align: justify;\">\r\n<li>h&aacute;bitos alimentares;</li>\r\n<li>equil&iacute;brio e consci&ecirc;ncia postural, diminuindo dores articulares e tens&otilde;es musculares;</li>\r\n<li>educa&ccedil;&atilde;o respirat&oacute;ria;</li>\r\n<li>gerenciamento do estresse e problemas relacionados: card&iacute;acos, digestivos, circulat&oacute;rios e&nbsp;respirat&oacute;rios.</li>\r\n</ul>\r\n</div>\r\n<p style=\"text-align: justify;\"><br />&Eacute; importante lembrar que o tratamento proposto aqui n&atilde;o substitue o tratamento m&eacute;dico oftalmol&oacute;gico convencional. Consulte regularmente o seu oftalmologista, pois o m&eacute;todo de tratamento natural proposto aqui &eacute; complementar &agrave; sua sa&uacute;de visual. N&atilde;o desautoriza nem desestimula, de forma alguma, a continuidade do tratamento m&eacute;dico oftalmol&oacute;gico.</p>\r\n<p style=\"text-align: justify;\"><strong>&Eacute; POSS&Iacute;VEL</strong> ter olhos e corpo cada vez mais saud&aacute;veis atrav&eacute;s de recursos naturais dispon&iacute;veis a quem queira a melhora. Os tratamentos naturais, agem n&atilde;o s&oacute; nos sintomas, mas tamb&eacute;m nas causas dos problemas visuais e corporais, sendo uma eficaz alternativa de desenvolver mais <strong>SA&Uacute;DE VISUAL e CORPORAL</strong>.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: center;\"><strong>Passe por essa experi&ecirc;ncia agora mesmo e sinta os benef&iacute;cios em seu corpo. </strong></p>\r\n<p style=\"text-align: center;\"><strong>Sua sa&uacute;de agradece.</strong></p>', '+-visão–-olhos-sempre-saudáveis.jpeg', NULL, NULL, '00:00', 1, 1, 0.00, 0.00, NULL, NULL, NULL, 1, 3, 9, '2019-12-02 17:34:35', '2019-12-02 17:34:35'),
(11, 'Programa vencendo a dor crônica', 'programa-vencendo-a-dor-cronica', '<div class=\"col-md-9\">\r\n<div class=\"title-two p-2\">\r\n<h4 class=\"text-warning text-center inter-600\">O mais completo programa de alivio &agrave;s dores cr&ocirc;nicas do Brasil</h4>\r\n<p class=\"text-center text-white inter-400 h5\">Pela primeira vez ser&aacute; revelado o mais completo m&eacute;todo que o livrar&aacute; das dores cr&ocirc;nicas, reduzindo at&eacute; 90% das dores em menos de 30 dias. <br />Descubra o passo a passo do m&eacute;todo que j&aacute; promoveu al&iacute;vio das dores de mais de 5.330 pessoas.</p>\r\n</div>\r\n</div>', 'programa-vencendo-a-dor-crônica.jpeg', 'https://vimeo.com/437619314', NULL, NULL, 1, 1, 697.00, 627.00, NULL, NULL, NULL, 1, 3, 9, '2020-07-21 22:06:55', '2020-07-21 22:06:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `course_inscription`
--

CREATE TABLE `course_inscription` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `inscription_id` bigint(20) UNSIGNED NOT NULL,
  `course` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `price` double(10,2) DEFAULT NULL,
  `subtotal` double(10,2) DEFAULT NULL,
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `course_inscription`
--

INSERT INTO `course_inscription` (`id`, `course_id`, `inscription_id`, `course`, `amount`, `price`, `subtotal`, `status`, `code`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 'Asma princípios preventivos', 1, 0.00, 0.00, '5', NULL, '2020-06-22 15:49:03', '2020-07-20 21:20:46'),
(2, 4, 1, 'detox-figado', 1, 0.00, 0.00, '4', NULL, '2020-07-20 22:29:54', '2020-07-20 22:29:54'),
(3, 11, 1, 'programa-vencendo-a-dor-cronica', 1, 697.00, 697.00, '5', NULL, '2020-07-21 23:34:41', '2020-07-21 23:35:46');

-- --------------------------------------------------------

--
-- Estrutura da tabela `inscriptions`
--

CREATE TABLE `inscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cep` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `neighborhood` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ibge` int(11) NOT NULL,
  `email_inscription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `inscriptions`
--

INSERT INTO `inscriptions` (`id`, `user_id`, `name`, `cpf`, `cep`, `street`, `neighborhood`, `city`, `state`, `ibge`, `email_inscription`, `phone`, `company`, `company_phone`, `status`, `created_at`, `updated_at`) VALUES
(1, 6, 'Karoliny Irineu', '863.165.845-63', '44.300-000', 'Coimbra', 'Cacpoiruçu', 'Cachoeira', 'BA', 0, 'karoliny.irineu26@gmail.com', '(75) 99243-8993', 'EDESSOFT', '(21) 99572-5597', '0', '2020-06-22 15:49:03', '2020-07-20 22:27:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu` int(10) UNSIGNED NOT NULL,
  `depth` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_08_11_073824_create_menus_wp_table', 1),
(4, '2017_08_11_074006_create_menu_items_wp_table', 1),
(5, '2019_02_07_201823_create_sections_table', 1),
(6, '2019_02_07_201942_create_pages_table', 1),
(7, '2019_02_07_202016_create_categories_table', 1),
(8, '2019_02_07_202439_create_posts_table', 1),
(9, '2019_02_07_202551_create_universities_table', 1),
(10, '2019_02_07_202728_create_careers_table', 1),
(11, '2019_02_07_203244_create_periods_table', 1),
(12, '2019_02_07_203304_create_trainees_table', 1),
(13, '2019_03_22_235123_create_courses_table', 1),
(14, '2019_03_22_235437_create_modules_table', 1),
(15, '2019_03_22_235738_create_classrooms_table', 1),
(16, '2019_03_23_134213_create_sales_table', 1),
(17, '2019_04_10_204906_create_permission_tables', 1),
(18, '2019_04_19_161613_create_assignments_table', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(2, 'App\\User', 2),
(3, 'App\\User', 3),
(5, 'App\\User', 5),
(5, 'App\\User', 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `modules`
--

CREATE TABLE `modules` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `modules`
--

INSERT INTO `modules` (`id`, `name`, `description`, `status`, `course_id`, `created_at`, `updated_at`) VALUES
(5, 'Exercícios globais', 'OS EXERCICIOS GLOBAIS E DIVIDIDOS EM 3 CATEGORIAS:\r\n1ª CATEGORIA: Exercícios de reajustes articulares\r\n2ª CATEGORIA: Exercícios de alongamentos musculares \r\n3ª CATEGORIA: Exercícios de fortal', 1, 11, '2020-07-21 22:15:23', '2020-07-21 22:15:23'),
(6, 'Exercícios específicos', 'Área para exercícios específicos', 1, 11, '2020-07-21 22:47:14', '2020-07-21 22:47:14'),
(7, 'Bônus', 'Área para colocar os bônus', 1, 11, '2020-07-21 23:03:40', '2020-07-21 23:03:40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `redirect` int(11) DEFAULT NULL,
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `section_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `pages`
--

INSERT INTO `pages` (`id`, `parent_id`, `title`, `slug`, `description`, `content`, `enabled`, `redirect`, `external_url`, `target`, `order`, `section_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 0, 'Home', 'home', '<p>home</p>', '<p>home</p>', 0, 1, '/#inicio', '_parent', 1, 1, 3, '2019-05-06 16:55:57', '2019-09-18 14:44:07'),
(2, 0, 'Quem somos', 'quem-somos', NULL, '<div class=\"content-wrap\">\r\n<section id=\"vision\" class=\"section white-blue\">\r\n<div class=\"container\">\r\n<div class=\"target-big col-md-4 col-sm-4 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/Bem-vindo.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n<div class=\"col-md-8 col-sm-8 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Seja Bem Vindo!</h3>\r\n<p class=\"oriental\">A Pr&oacute;-Sa&uacute;de Integral</p>\r\n<p id=\"visao\" class=\"mission-text\" style=\"color: #363636;\">A Pr&oacute;-Sa&uacute;de Integral &eacute; uma Empresa comprometida com a promo&ccedil;&atilde;o da sa&uacute;de integral envolvendo os aspectos f&iacute;sico, mental e social atrav&eacute;s da mudan&ccedil;a de h&aacute;bitos e estilo de vida, potencializando significativamente o desenvolvimento integral do ser e o desenvolvimento intra e inter-pessoal.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<section id=\"mission\" class=\"section blue-light-2\">\r\n<div class=\"container\">\r\n<div class=\"mission-text-box col-md-8 col-sm-8 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Filosofia</h3>\r\n<p class=\"oriental\">Nossas a&ccedil;&otilde;es est&atilde;o alinhadas com nossos valores</p>\r\n<p class=\"mission-text\">Promover a sa&uacute;de f&iacute;sica, mental e social atrav&eacute;s da mudan&ccedil;a de h&aacute;bitos e estilo de vida, potencializando significativamente o desempenho intra e inter-pessoal e profissional, desenvolvendo maior sociabilidade no ambiente de trabalho e demais grupos sociais.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm col-md-4 col-sm-4 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"vision-img img-responsive\" src=\"http://127.0.0.1:8000/img/psi/filosofia.png\" alt=\"Nossa Miss&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"vision\" class=\"section white-blue\">\r\n<div class=\"container\">\r\n<div class=\"target-big col-md-4 col-sm-4 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/visao.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n<div class=\"col-md-8 col-sm-8 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Miss&atilde;o</h3>\r\n<p class=\"oriental\">A nossa raz&atilde;o de exist&ecirc;ncia</p>\r\n<p id=\"visao\" class=\"mission-text\" style=\"color: #363636;\">Atuar, atrav&eacute;s de uma experiente equipe multidisciplinar de profissionais especializados, de forma din&acirc;mica, criativa, consciente e com qualidade, promovendo atrav&eacute;s do cuidado integral, condi&ccedil;&otilde;es para que os clientes e as corpora&ccedil;&otilde;es empresariais desenvolvam suas atividades com seguran&ccedil;a, conforto e maior efici&ecirc;ncia, obtendo produtividade com qualidade. Facilitar o acesso das pessoas a orienta&ccedil;&otilde;es quanto a um viver saud&aacute;vel, Promovendo a recupera&ccedil;&atilde;o do estado de sa&uacute;de de nossos clientes, atrav&eacute;s de m&eacute;todos comprovadamente eficientes e com aten&ccedil;&atilde;o personalizada, utilizando m&eacute;todos preventivos.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm target-small col-md-4 col-sm-4 wow fadeInLeft animated\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/visao.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"mission\" class=\"section blue-light-2\">\r\n<div class=\"container\">\r\n<div class=\"mission-text-box col-md-8 col-sm-8 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Vis&atilde;o</h3>\r\n<p class=\"oriental\">Aonde n&oacute;s queremos chegar</p>\r\n<p class=\"mission-text\">Ser refer&ecirc;ncia em atendimento e promo&ccedil;&atilde;o da sa&uacute;de, atrav&eacute;s do conceito que parte da preven&ccedil;&atilde;o e diagn&oacute;stico para oferecer muito mais qualidade de vida. Cremos que os seres humanos podem adquirir melhor sa&uacute;de a fim de desenvolverem uma vida mais produtiva e plena de sentido que d&ecirc; valor e dignidade &agrave; essa exist&ecirc;ncia, ajudando os semelhantes a viverem com dignidade no presente e ensinando-os a serem mais longevos e com qualidade de vida.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm col-md-4 col-sm-4 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"vision-img img-responsive\" src=\"http://127.0.0.1:8000/img/psi/missao.png\" alt=\"Nossa Miss&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"vision\" class=\"section white-blue\">\r\n<div class=\"container\">\r\n<div class=\"target-big col-md-4 col-sm-4 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/lema.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n<div class=\"col-md-8 col-sm-8 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Lema</h3>\r\n<!--<p class=\"oriental\">A nossa razão de existência</p>-->\r\n<p id=\"visao\" class=\"mission-text\" style=\"color: #363636;\">Acesso &agrave; sa&uacute;de integral e acessibilidade a todos que desejam mais sa&uacute;de e longevidade.</p>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm target-small col-md-4 col-sm-4 wow fadeInLeft animated\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"img-responsive\" src=\"http://127.0.0.1:8000/img/psi/lema.png\" alt=\"Nossa Vis&atilde;o\" /></div>\r\n</div>\r\n</section>\r\n<section id=\"values\" class=\"section blue-light-2\">\r\n<div class=\"container\">\r\n<div class=\"col-md-8 col-sm-8 wow fadeInLeft\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInLeft;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\">\r\n<div class=\"feature-item\">\r\n<h3 class=\"title-small valores\">Valores</h3>\r\n<p class=\"oriental\">&nbsp;</p>\r\n<ul id=\"Valores\" class=\"mission-text list-item\">\r\n<li>Atendimento humanizado</li>\r\n<li>Confian&ccedil;a e respeito nas rela&ccedil;&otilde;es</li>\r\n<li>Transpar&ecirc;ncia e &eacute;tica</li>\r\n<li>Qualidade total em todos os processos</li>\r\n<li>Trabalho em equipe</li>\r\n<li>Inova&ccedil;&atilde;o e Responsabilidade social</li>\r\n</ul>\r\n</div>\r\n</div>\r\n<div class=\"hide-sm col-md-4 col-sm-4 wow fadeInRight\" style=\"visibility: visible; animation-duration: 1000ms; animation-delay: 300ms; animation-name: fadeInRight;\" data-wow-duration=\"1000ms\" data-wow-delay=\"300ms\"><img class=\"vision-img img-responsive\" src=\"http://127.0.0.1:8000/img/psi/valores.png\" alt=\"Nossos Valores\" /></div>\r\n</div>\r\n</section>\r\n</div>', 1, 1, '/quem-somos', '_parent', 2, 1, 3, '2019-05-06 16:57:35', '2019-05-21 04:21:39'),
(3, 0, 'Treinamentos', 'treinamentos', '<p>Treinamentos</p>', '<p>Treinamentos</p>', 1, 1, '/#treinamentos', '_parent', 3, 1, 3, '2019-05-06 16:58:16', '2019-05-13 00:11:08'),
(4, 0, 'Consultorias', 'consultorias', '<p>Consultorias</p>', '<p>Consultorias</p>', 1, 1, '/#programas', '_parent', 4, 1, 3, '2019-05-06 16:58:57', '2019-06-16 04:51:58'),
(5, 0, 'Clinica', 'clinica', '<p>Clinica</p>', '<p>Clinica</p>', 0, 0, NULL, '_parent', 5, 1, 3, '2019-05-06 17:03:12', '2019-05-29 04:28:19'),
(6, 5, 'Clube da vantagens', 'clube-da-vantagens', '<p>Clube da vantagens</p>', '<h2><strong>Aposte nesses benef&iacute;cios!&nbsp; Proteja seu bolso</strong></h2>\r\n<p style=\"text-align: justify;\"><img style=\"border-width: 2px; float: left; margin: 20px;\" src=\"http://127.0.0.1:8000/uploads/source/page/psi-clube-de-vantagens.png\" alt=\"\" width=\"520\" height=\"198\" />Para a Pr&oacute;-Sa&uacute;de Integral cuidar dos seus clientes &eacute; mais que oferecer atendimento e servi&ccedil;os de qualidade, &eacute; proporcionar uma solu&ccedil;&atilde;o completa em sa&uacute;de.&nbsp;</p>\r\n<p style=\"text-align: justify;\">Dessa forma, em parceria com uma extensa rede de estabelecimentos credenciados, foi desenvolvido especialmente para os clientes Pr&oacute;-Sa&uacute;de Integral o Clube de Vantagens. Uma s&eacute;rie de descontos em produtos e servi&ccedil;os relacionados &agrave; sa&uacute;de, qualidade de vida e bem-estar.</p>\r\n<p style=\"text-align: justify;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral &eacute; uma vitrine de ofertas e benef&iacute;cios exclusivos para clientes Fidelidade. O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral tem o objetivo de fidelizar e aumentar a aproxima&ccedil;&atilde;o dos clientes com as empresas, por meio de ofertas e vantagens. A Pr&oacute;-Sa&uacute;de Integral tem compromisso em manter apenas parceiros que ofere&ccedil;am produtos e/ou servi&ccedil;os de&nbsp;<strong>qualidade.</strong></p>\r\n<p style=\"text-align: justify;\"><strong>Saiba como funciona</strong></p>\r\n<p style=\"text-align: justify;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral &eacute; uma rede de ofertas exclusiva para clientes Pr&oacute;-Sa&uacute;de Integral. Para usar os descontos do portal em lojas f&iacute;sicas, &eacute; necess&aacute;rio fazer o cadastro e obter cart&atilde;o Clin Card e apresent&aacute;-lo ao lojista no momento da compra. Caso tenha alguma d&uacute;vida, consulte a mec&acirc;nica de cada oferta.</p>\r\n<p style=\"text-align: justify;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral n&atilde;o se responsabiliza por qualquer dano causado por parceiros.</p>', 1, 0, NULL, '_parent', 1, 1, 3, '2019-05-06 17:04:03', '2019-05-23 02:44:50'),
(7, 5, 'Loja', 'loja', '<p>Loja</p>', '<p>Loja</p>', 1, 0, NULL, '_parent', 2, 1, 3, '2019-05-06 17:04:46', '2019-05-06 17:04:46'),
(8, 5, 'Dropdown2', 'dropdown2', '<p>Dropdown2</p>', '<p>Dropdown2</p>', 0, 0, NULL, '_parent', 3, 1, 3, '2019-05-06 17:22:51', '2019-05-26 21:25:39'),
(9, 8, 'Sub menu 2', 'sub-menu-2', '<p>Sub menu 2</p>', '<p>Sub menu 2</p>', 1, 0, NULL, '_parent', 1, 1, 3, '2019-05-06 17:23:30', '2019-05-06 17:23:30'),
(10, 8, 'Dropdown3', 'dropdown3', '<p>Dropdown3</p>', '<p>Dropdown3</p>', 1, 0, NULL, '_parent', 2, 1, 3, '2019-05-06 17:24:01', '2019-05-06 17:25:46'),
(11, 0, 'Produtos', 'produtos', '<p>Produtos</p>', '<p><img src=\"https://prosaudeintegral.com.br/uploads/source/treinamentos/comense-a-vivir.jpg\" alt=\"\" width=\"100%\" height=\"auto\" /><img src=\"http://127.0.0.1:8000/uploads/source/treinamentos/Imagem3.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<div class=\"card p-4\">\r\n<p style=\"text-align: justify;\">Se h&aacute; uma coisa que rouba a nossa alegria e sa&uacute;de s&atilde;o as dores corporais. <br />&Eacute; interessante como afeta 90% das pessoas em fase produtiva! <br />Os fatores causadores s&atilde;o variados:</p>\r\n<ul class=\"pl-4 pr-4\" style=\"text-align: justify;\">\r\n<li>Estresse,</li>\r\n<li>Posturas incorretas</li>\r\n<li>Obesidade</li>\r\n<li>Idade</li>\r\n<li>Sedentarismo...</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">O fato &eacute; que a maioria das pessoas n&atilde;o sabe como amenizar o sofrimento, e vira um ciclo vicioso de dor - rem&eacute;dio - ins&ocirc;nia - estresse. Rem&eacute;dios s&atilde;o apenas paliativos ilus&oacute;rios. Al&eacute;m de n&atilde;o resolverem o problema, cronifica o quadro doloroso e intoxica o corpo. Conhecer como funciona a din&acirc;mica corporal &eacute; fundamental no trajeto de resolu&ccedil;&atilde;o das dores musculares e esquel&eacute;ticas.</p>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div class=\"card pt-3 mb-3\">\r\n<div class=\"row no-gutters align-items-center\">\r\n<div class=\"col-md-8\">\r\n<div class=\"card-body\">\r\n<h5 class=\"card-title\">O que voc&ecirc; encontrar&aacute; nesse Manual?</h5>\r\n<ul>\r\n<li>Conhecer&aacute; como funciona a coluna vertebral e sua inter-rela&ccedil;&atilde;o com outros &oacute;rg&atilde;os e sistemas corporais;</li>\r\n<li>Aprender&aacute; a identificar as poss&iacute;veis causas originadoras de dores nas costas;</li>\r\n<li>A rela&ccedil;&atilde;o dos padr&otilde;es posturais e as dores cr&ocirc;nicas;</li>\r\n<li>Por qu&ecirc; a obesidade, estresse e gestantes evoluem com dores nas costas;</li>\r\n<li>A import&acirc;ncia de posturas corretas nas atividades do lar e do trabalho;</li>\r\n<li>Os cuidados redobrados na terceira idade;</li>\r\n<li>S&atilde;o dezenas de orienta&ccedil;&otilde;es, exemplificadas atrav&eacute;s de imagens fotogr&aacute;ficas, para que voc&ecirc; possa se livrar de suas dores.</li>\r\n</ul>\r\n<p class=\"card-text\">&nbsp;</p>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4\"><img class=\"card-img\" src=\"https://res.cloudinary.com/prosaudeintegral/image/upload/v1560993671/psi/Imagem9_xl3t45.png\" alt=\"Sem dor\" width=\"100%\" height=\"auto\" /></div>\r\n</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div class=\"card bg-light mb-3 text-center\">\r\n<div class=\"card-header h2\">Esse Manual Dores nas Costas Nunca Mais! <br />servir&aacute; de grande norteador para que voc&ecirc; seja mais feliz sem dor.</div>\r\n</div>\r\n<div class=\"row pt-4 justify-content-center align-items-center\">\r\n<div class=\"col-xs-12 col-md-5 text-center\"><a class=\"btn btn-primary btn-lg text-white\" title=\"LIVRO\" href=\"https://pag.ae/7UYP_c3hN\" target=\"_blank\" rel=\"noopener\">ADQUIRIR <br /></a>\r\n<h4>LIVRO</h4>\r\n</div>\r\n</div>', 1, 1, '/produtos', '_parent', 5, 1, 3, '2019-05-06 17:26:20', '2019-07-01 21:27:36'),
(12, 0, 'Contato', 'contato', '<p>Contato</p>', '<p>Contato</p>', 1, 1, '/#contato', '_parent', 12, 1, 3, '2019-05-06 17:41:13', '2019-05-29 21:28:42'),
(13, 0, 'Programas', 'programas', '<p>Descri&ccedil;&atilde;o</p>', '<p>Conteudo</p>', 1, 1, '/#programas', '_parent', 6, 1, 3, '2019-05-29 04:31:30', '2019-05-29 04:31:46'),
(14, 0, 'Especialidades', 'especialidades', NULL, '<p>Conteudo</p>', 1, 1, '/#programas', '_parent', 7, 1, 3, '2019-05-29 04:32:17', '2019-06-16 04:52:48'),
(15, 0, 'Dicas e ferramentas', 'dicas-e-ferramentas', '<p>Descri&ccedil;&atilde;o</p>', '<p>Conteudo</p>', 1, 1, '/#dicas', '_parent', 8, 1, 3, '2019-05-29 04:33:07', '2019-06-16 04:53:36'),
(16, 0, 'Eventos', 'eventos', NULL, '<p>Conteudo</p>', 1, 1, '/#eventos', '_parent', 9, 1, 3, '2019-05-29 04:33:39', '2019-06-16 04:54:06');

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `periods`
--

CREATE TABLE `periods` (
  `id` int(10) UNSIGNED NOT NULL,
  `year` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'create user', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(2, 'read users', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(3, 'update user', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(4, 'delete user', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(5, 'create role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(6, 'read role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(7, 'update role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(8, 'delete role', 'web', '2019-05-06 14:54:16', '2019-05-06 14:54:16'),
(9, 'create permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(10, 'read permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(11, 'update permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(12, 'delete permission', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(13, 'home index', 'web', '2019-12-02 14:23:10', '2019-12-02 14:23:10');

-- --------------------------------------------------------

--
-- Estrutura da tabela `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `image`, `content`, `date_start`, `date_end`, `description`, `target`, `status`, `external_url`, `redirect`, `author`, `payment_link`, `order`, `category_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Seminário Saúde e Longevidade', 'seminario-saude-e-longevidade', '1564321622.jpg', '<div id=\"accordion\" class=\"panel-group\">\r\n<div class=\"panel panel-default\">\r\n<div id=\"headingOne\" class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a href=\"#collapseOne\" data-toggle=\"collapse\" data-parent=\"#accordion\"> VISUALIZAR CARTAZ</a></h4>\r\n</div>\r\n<div id=\"collapseOne\" class=\"panel-collapse collapse\">\r\n<div class=\"panel-body\"><a style=\"background: #fff;\" title=\"\" href=\"http://127.0.0.1:8000/img/psi/projetos/SaUde-e-Longevidade.jpg\"><img src=\"https://res.cloudinary.com/prosaudeintegral/image/upload/v1560989013/psi/cartaz-seminario-saude-e-longevidade_rmchqr.jpg\" alt=\"\" width=\"786\" height=\"1125\" /></a></div>\r\n</div>\r\n</div>\r\n</div>\r\n<p style=\"text-align: justify;\">O Semin&aacute;rio de Sa&uacute;de e longevidade consiste de um ciclo de palestras, objetivando reavivar os conceitos da inter-rela&ccedil;&atilde;o envolvendo o trip&eacute; da sa&uacute;de plena: sa&uacute;de f&iacute;sica, mental e f&eacute;. &Eacute; um dia destinado &agrave; imers&atilde;o no aprendizado quanto ao desenvolvimento da sa&uacute;de e longevidade.</p>\r\n<p style=\"text-align: justify;\">&Eacute; um evento impactante, pois enche os participantes de motiva&ccedil;&atilde;o, para mudar os rumos da sua vida quanto a como desenvolver efetivamente um corpo saud&aacute;vel, como enxergar o mundo nas quest&otilde;es fracasso e sucesso e como desenvolver mais f&eacute;. Acima de tudo, esse evento promove uma profunda reflex&atilde;o para mudan&ccedil;a de h&aacute;bitos que atrapalham a jornada rumo ao sucesso, nos v&aacute;rios aspectos da vida.</p>\r\n<p><strong>Objetivos do Semin&aacute;rio Sa&uacute;de e Longevidade </strong></p>\r\n<ul>\r\n<li>Promover uma imers&atilde;o no autoconhecimento da vida, nas quest&otilde;es de sa&uacute;de f&iacute;sica, mental e relacionamentos;</li>\r\n<li>Apresentar como desenvolver o perfil do sucesso em tudo que fizer;</li>\r\n<li>Desenvolver a percep&ccedil;&atilde;o de como se originam as doen&ccedil;as;</li>\r\n<li>Gerar a compreens&atilde;o da rela&ccedil;&atilde;o entre sa&uacute;de com os h&aacute;bitos;</li>\r\n<li>Despertar o desejo de viver de acordo com os princ&iacute;pios naturais de cura para manter ou ganhar a sa&uacute;de perdida;</li>\r\n<li>Desenvolver a percep&ccedil;&atilde;o de que viver sem f&eacute; &eacute; condi&ccedil;&atilde;o incompat&iacute;vel com a vida;</li>\r\n<li>Desenvolver a consci&ecirc;ncia de que &eacute; poss&iacute;vel ser a pessoa que deseja ser: feliz, realizada, proativa produtiva.</li>\r\n</ul>\r\n<p><strong>Temas</strong></p>\r\n<p style=\"padding-left: 40px;\"><strong>1. Viva com Prop&oacute;sito&nbsp;</strong></p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">Se voc&ecirc; n&atilde;o tem um sonho a alcan&ccedil;ar na vida, n&atilde;o tem um objetivo definido que o motive, n&atilde;o tem uma raz&atilde;o para viver e vencer, pode se considerar o mais infeliz de todos! Essa palestra vi mexer com voc&ecirc;! Sua vida n&atilde;o ser&aacute; mais a mesma, pois voc&ecirc; aprender&aacute; as ferramentas para o sucesso na vida.</p>\r\n<p style=\"padding-left: 40px;\"><strong>2. Sa&uacute;de Plena em um mundo doente</strong></p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">As pessoas est&atilde;o ligadas no autom&aacute;tico de h&aacute;bitos geradores de doen&ccedil;as. Como &eacute; poss&iacute;vel ter sa&uacute;de e andar na mar&eacute; contr&aacute;ria da tend&ecirc;ncia da sociedade?</p>\r\n<p style=\"padding-left: 40px;\"><strong>3. Princ&iacute;pios para sa&uacute;de e longevidade</strong></p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">Assim como tudo no universo &eacute; regido por leis, o corpo tamb&eacute;m &eacute; controlado por princ&iacute;pios. A transgress&atilde;o desses princ&iacute;pios resultar&aacute; em desequil&iacute;brio das atividades, denominado doen&ccedil;a. Ao seguir os princ&iacute;pios que governam as fun&ccedil;&otilde;es corporais a vida &eacute; perpetuada de forma equilibrada.</p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">Nesse tema &eacute; apresentado princ&iacute;pios corporais que garantem mais sa&uacute;de e longevidade.</p>\r\n<p style=\"padding-left: 40px;\"><strong>4. Dores cr&ocirc;nicas nunca mais!</strong></p>\r\n<p style=\"padding-left: 40px;\">O tema aborda tr&ecirc;s situa&ccedil;&otilde;es s&eacute;rias:</p>\r\n<ol>\r\n<li style=\"list-style-type: none; font-size: 15px;\">\r\n<ol>\r\n<li>alt&iacute;ssima incid&ecirc;ncia de dores cr&ocirc;nicas, uma queixa geral;</li>\r\n<li>99.9% das pessoas que sofrem dores cr&ocirc;nicas, n&atilde;o sabem a causa ou fator que originou suas queixas;</li>\r\n<li>o tratamento ofertado pelo sistema convencional &eacute; basicamente sintomatol&oacute;gico, gerando apenas efeito paliativo. Ningu&eacute;m &eacute; orientado quanto mudan&ccedil;as de h&aacute;bitos.</li>\r\n</ol>\r\n</li>\r\n</ol>\r\n<p style=\"padding-left: 40px;\"><strong>5. + Vis&atilde;o: trate seus olhos naturalmente</strong></p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">Pense como seria sua vida se perdesse a vis&atilde;o! N&atilde;o seria terr&iacute;vel?</p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">Diariamente pessoas, cada vez mais novas, s&atilde;o acometidas de problemas visuais e, a partir de ent&atilde;o, come&ccedil;am a usar &oacute;culos, tornando-se eternos escravos. &Eacute; esse modelo terap&ecirc;utico que o sistema convencional disponibiliza a todas as pessoas que sofrem dos olhos. H&aacute; alternativa? A resposta &eacute; sim!</p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">Esse tema apresenta as causas e como reduzir os problemas visuais em tempo relativamente curto.</p>\r\n<p style=\"padding-left: 40px;\"><strong>6. Equil&iacute;brio emocional nos relacionamentos</strong></p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">A ansiedade &eacute; considerado o mal do s&eacute;culo. Parece que est&aacute; presente na vida de todo mundo. As pessoas vivem estressadas, a um n&iacute;vel tal que afeta o relacionamento intra e interpessoal. A falta de f&eacute; e a vis&atilde;o perceptiva do mundo altera facilmente o estado de humor.</p>\r\n<p style=\"padding-left: 40px; text-align: justify;\">O tema esbo&ccedil;a os efeitos das altera&ccedil;&otilde;es emocionais sobre as fun&ccedil;&otilde;es do corpo e da mente e grau de comprometimento nos relacionamentos pessoais e profissionais. A pergunta &eacute;: como administrar essa situa&ccedil;&atilde;o e ter mais controle das emo&ccedil;&otilde;es? Trabalhamos sugest&otilde;es que certamente o auxiliar&aacute; a ter mais controle sobre as emo&ccedil;&otilde;es, de forma estrat&eacute;gica.</p>\r\n<p style=\"padding-left: 40px; text-align: center;\"><strong>QUER O SEMIN&Aacute;RIO SA&Uacute;DE E LONGEVIDADE EM SUA LOCALIDADE? ENTRE EM </strong></p>\r\n<p style=\"padding-left: 40px; text-align: center;\"><a class=\"btn btn-yellow\" title=\"Contato\" href=\"mailto:contato@prosaudeintegral.com.br\" target=\"_blank\" rel=\"noopener\"><strong>CONTATO CONOSCO </strong></a></p>\r\n<p style=\"padding-left: 40px; text-align: center;\">&nbsp;</p>', '2019-05-06', '2019-05-31', NULL, '_parent', 0, 'http://127.0.0.1:8000/', '0', 'Eber Ortiz Mas', NULL, 1, 2, 3, '2019-05-06 20:04:16', '2019-10-28 17:31:46'),
(2, 'Equilibrio', 'equilibrio', '1558882110.jpg', '<p><span style=\"color: #000000;\">DESENVOLVA O EQUIL&Iacute;BRIO</span><br /><span style=\"color: #000000;\"> F&Iacute;SICO</span><br /><span style=\"color: #000000;\"> INTELECTUAL</span><br /><span style=\"color: #000000;\"> EMOCIONAL</span><br /><span style=\"color: #000000;\"> SOCIAL</span><br /><span style=\"color: #000000;\"> AMBIENTAL</span><br /><span style=\"color: #000000;\"> ESPIRITUAL</span></p>', '2019-05-06', '2019-05-31', NULL, '_parent', 0, NULL, '0', 'Eber Ortiz Mas', NULL, 2, 2, 3, '2019-05-06 20:11:08', '2019-06-05 04:34:20'),
(3, 'Atitude', 'atitude', '1558882172.jpg', '<p style=\"text-align: left;\"><strong><span style=\"font-size: 14pt;\"><span style=\"font-size: 24pt;\">Tenha uma gota de atitude</span> <br /></span></strong><br />Nada pode ser feito pelo ontem, <br />pois j&aacute; passou, nem pelo amanh&atilde;<br />pois n&atilde;o existe.<br />Viva integralmente o presente,<br />pois &eacute; o &uacute;nico presente que <br />Deus lhe deu. <br />Seu sucesso depende da atitude<br />tomada ap&oacute;s um grande tombo.</p>', '2019-05-06', '2019-05-31', NULL, '_parent', 0, NULL, '0', NULL, NULL, 3, 2, 3, '2019-05-06 20:13:45', '2019-06-05 04:34:10'),
(4, 'O home', 'o-home', '1558882209.jpg', '<p style=\"text-align: center;\"><span style=\"font-size: 24pt;\"><strong>Por qu&ecirc; os homens surpreendem?</strong></span><br /><span style=\"font-size: 18pt;\">\"Porque perdem a sa&uacute;de para juntar dinheiro, depois perdem dinheiro para recuperar a sa&uacute;de.</span><br /><span style=\"font-size: 18pt;\">E por pensarem ansiosamente no futuro, esquecem do presente de tal forma que acabam por n&atilde;o viver nem o presente nem o futuro.</span><br /><span style=\"font-size: 18pt;\">E vivem como se nunca fossem morrer. E morrem como se nunca tivessem vivido.\"&nbsp;</span><br /><span style=\"font-size: 18pt;\"> Dalai Lama</span></p>', '2019-05-06', '2019-05-31', NULL, '_parent', 0, NULL, '0', NULL, NULL, 4, 2, 3, '2019-05-06 20:14:56', '2019-06-05 04:34:01'),
(5, 'Mente empreendedora', 'mente-empreendedora', '1558304980.jpg', '<h2 style=\"text-align: center;\">O que esperar do treinamento MENTE EMPREENDEDORA</h2>\r\n<p><img src=\"http://127.0.0.1:8000/uploads/source/treinamentos/9%20LICOES.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<h2 style=\"text-align: center;\">Voc&ecirc; deseja ter sucesso na vida? sente que sua vida poderia ser mais?</h2>\r\n<p style=\"text-align: justify;\">Anseia por deixar sua marca no mundo e tem o desejo de fazer a diferen&ccedil;a atrav&eacute;s de uma vida com prop&oacute;sito?<br />Tem um sonho, mas n&atilde;o sabe por onde come&ccedil;ar, pois n&atilde;o se sentiu ainda empoderado o suficiente para dar o primeiro passo?<br />Voc&ecirc; sente bem l&aacute; dentro como se estivesse faltando algo, uma pe&ccedil;a chave para viver uma vida mais m&aacute;gica, repleta de motiva&ccedil;&atilde;o e entusiasmo?</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; v&ecirc; que o mundo est&aacute; avan&ccedil;ando e que voc&ecirc; est&aacute; ficando para tr&aacute;s?</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; quer sentir-se como v&iacute;tima das circunstancias ou quer avan&ccedil;ar com o mundo, criando as circunst&acirc;ncias para o seu sucesso, sendo a estrela principal em seu pr&oacute;prio filme? Ent&atilde;o, <strong>viva com prop&oacute;sito!</strong> Tenha um sonho em mente e realize-o em sua vida!</p>\r\n<h2 style=\"text-align: center;\"><em>&ldquo;As pessoas de maior resultado t&ecirc;m<br />um forte prop&oacute;sito por tr&aacute;s de cada<br />a&ccedil;&atilde;o em sua vida&rdquo;</em></h2>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: center;\">Todos os vision&aacute;rios s&atilde;o movidos por um prop&oacute;sito definido em suas vidas.</p>\r\n<p style=\"text-align: center;\"><strong><u>o prop&oacute;sito &eacute; a chave para a transforma&ccedil;&atilde;o</u></strong><strong>.</strong></p>\r\n<p style=\"text-align: justify;\">O estudo acad&ecirc;mico te d&aacute; um conhecimento valioso, mas nunca te ensinou a pensar para o sucesso. Em casa, no trabalho e no meio de conviv&ecirc;ncia, voc&ecirc; n&atilde;o foi ensinado nem estimulado sobre prop&oacute;sito de vida e estrat&eacute;gias para ser uma pessoa de sucesso. Isso culmina com confus&atilde;o, frustra&ccedil;&atilde;o e fracasso. Por isso muitos n&atilde;o conseguem ser bem sucedidos na vida.</p>\r\n<p>Se voc&ecirc; &eacute; uma pessoa que:</p>\r\n<ul>\r\n<li>Gostaria de alterar radicalmente pelo menos uma &aacute;rea de sua vida.</li>\r\n<li>J&aacute; &nbsp;tentou fazer isso antes, mas n&atilde;o obteve os resultados desejados.</li>\r\n<li>N&atilde;o est&aacute; pronto para desistir de uma vida mais feliz e mais gratificante.</li>\r\n<li>Est&aacute; insatisfeito com sua situa&ccedil;&atilde;o atual e deseja mudar, mas n&atilde;o sabe como.</li>\r\n<li>Tem um sonho (conseguir algo ou ser algo) que deseja realizar.</li>\r\n<li>Se considera incapaz.</li>\r\n<li>Quer ser bem sucedido na vida.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: center;\"><strong>Atrav&eacute;s desse treinamento voc&ecirc; ir&aacute; transformar todos os seus conceitos e vis&atilde;o de mundo.</strong></p>\r\n<p style=\"text-align: justify;\"><strong>&nbsp;</strong></p>\r\n<p style=\"padding-left: 40px;\">Ent&atilde;o, o que voc&ecirc; realmente quer para sua vida?<br />N&atilde;o se contente com o que voc&ecirc; acha que pode conseguir ...<br />N&atilde;o deixe que o medo, a sobrecarga ou os maus h&aacute;bitos o impe&ccedil;am.<br />Essa &eacute; sua vida. E voc&ecirc; merece e pode ter o melhor.<br />Se voc&ecirc; acha que vai chegar onde quer por acaso, pense novamente.&nbsp;&nbsp;&nbsp;&nbsp;<strong>&nbsp;<br /><br /></strong></p>\r\n<p style=\"text-align: center;\">O <strong>sucesso</strong> n&atilde;o ocorre por acaso!</p>\r\n<p style=\"text-align: justify;\">Atrav&eacute;s de um prop&oacute;sito definido e planos estrat&eacute;gicos bem elaborados voc&ecirc; adquirir&aacute; a autoconfian&ccedil;a e determina&ccedil;&atilde;o para criar a vida que voc&ecirc; realmente deseja, para perseguir seus maiores objetivos e assumir o controle de sua vida, experimentando a verdadeira satisfa&ccedil;&atilde;o de um viver com realiza&ccedil;&atilde;o plena.</p>\r\n<p style=\"text-align: justify;\">Com o treinamento de Coaching <strong>MENTE EMPREENDEDORA</strong> &ndash; <em>As Chaves que Maximizam Seus Potenciais para o Sucesso</em>, voc&ecirc; ir&aacute; desvendar os segredos do potencial humano atrav&eacute;s de um estudo profundo da mente, como &eacute; que voc&ecirc; se torna o que pensa e caminha rumo a um prop&oacute;sito definido para uma vida cheia de significado e realiza&ccedil;&otilde;es! Esse treinamento ir&aacute; capacit&aacute;-lo com a compreens&atilde;o que voc&ecirc; precisa para implementar os conceitos ensinados para que voc&ecirc; possa atingir qualquer objetivo que voc&ecirc; realmente deseja.</p>\r\n<p style=\"text-align: justify;\">Como funciona o programa de coaching<strong> MENTE EMPREENDEDORA?</strong></p>\r\n<p style=\"text-align: justify;\">O Programa de Coaching MENTE EMPREENDEDORA &eacute; um treinamento interativo de 09 meses projetado para ajud&aacute;-lo a entender e aplicar os princ&iacute;pios e conceitos que o levar&aacute; a descobrir o prop&oacute;sito de sua vida, seus sonhos e a desenvolver e maximizar as capacidades necess&aacute;rias para o sucesso. Com a aplica&ccedil;&atilde;o rigorosa em praticar esses princ&iacute;pios, voc&ecirc; experimentar&aacute; resultados incr&iacute;veis em todas as &aacute;reas de sua vida.</p>\r\n<p style=\"text-align: justify;\">Ao longo do treinamento voc&ecirc; conseguir&aacute; identificar os pensamentos do fracasso (h&aacute;bitos e cren&ccedil;as) que est&atilde;o impedindo voc&ecirc; de alcan&ccedil;ar os resultados que realmente deseja, em todas as &aacute;reas da sua vida. Aprender&aacute; a desenvolver pensamentos e atitudes que o conduzir&aacute; a subir os degraus do sucesso.</p>\r\n<p style=\"text-align: justify;\">N&oacute;s nos concentramos nas principais metas e objetivos que voc&ecirc; deseja alcan&ccedil;ar. Defina uma meta que seja digna de voc&ecirc; e n&oacute;s o orientaremos para sua realiza&ccedil;&atilde;o.</p>\r\n<p style=\"text-align: justify;\">Esse treinamento &eacute; uma combina&ccedil;&atilde;o estrategicamente projetada de educa&ccedil;&atilde;o, responsabilidade e a&ccedil;&atilde;o. A&ccedil;&atilde;o para a realiza&ccedil;&atilde;o progressiva de seus sonhos.</p>\r\n<p style=\"text-align: justify;\">Pensamos em tudo o que voc&ecirc; precisa para se concentrar no que realmente importa: o seu sucesso!</p>\r\n<p>&nbsp;</p>', '2019-05-06', '2019-05-31', '<p>O que esperar do treinamento MENTE EMPREENDEDORA</p>', '_parent', 0, NULL, '0', NULL, NULL, 1, 3, 3, '2019-05-06 21:52:34', '2019-06-07 19:35:00'),
(6, 'Dores nas costas nunca mais', 'dores_nas_costas_nunca_mais', '1558401370.jpg', '<p><img src=\"http://prosaudeintegral.com.br/uploads/source/treinamentos/Imagem3.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<p style=\"text-align: center;\">O que esperar do treinamento DORES NAS COSTAS NUNCA!</p>\r\n<p style=\"text-align: left;\"><img src=\"https://res.cloudinary.com/prosaudeintegral/image/upload/v1560651750/psi/dores-nas-costas_x15g5k.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<p style=\"text-align: justify;\">Como &eacute; bom sentir o al&iacute;vio das dores cr&ocirc;nicas ap&oacute;s algum&nbsp; procedimento! Melhor ainda &eacute; saber que o al&iacute;vio &eacute; permanente ap&oacute;s fazer uma terapia que que resolveu o problema na sua causa principal.</p>\r\n<p>Muitos s&atilde;o os fatores que desencadeiam as dores cr&ocirc;nicas. Alguns desses fatores s&atilde;o:</p>\r\n<ul>\r\n<li>sedentarismo,</li>\r\n<li>sobrepeso,</li>\r\n<li>falta de atividade f&iacute;sica,</li>\r\n<li>posturas incorretas nas atividades di&aacute;rias,</li>\r\n<li>tens&otilde;es e encurtamentos musculares,</li>\r\n<li>h&eacute;rnia discal,</li>\r\n<li>artrose,</li>\r\n<li>idosos,</li>\r\n<li>gravidez</li>\r\n<li>&nbsp;e outros problemas org&acirc;nicos sist&ecirc;micos.</li>\r\n</ul>\r\n<p><strong>&Eacute; importante enfatizar que:</strong></p>\r\n<p style=\"text-align: justify;\">as diferentes&nbsp;<strong>posturas</strong>&nbsp;adotadas no dia a dia e durante as atividades quotidianas, o sedentarismo e o estresse est&atilde;o entre as principais causas de dores cr&ocirc;nicas. Principalmente sobre essas causas o treinamento terap&ecirc;utico Dores nas Costas Nunca Mais ser&aacute; um divisor de &aacute;guas, em se tratando de resolu&ccedil;&atilde;o prolonga das dores cr&ocirc;nicas.</p>\r\n<p style=\"text-align: justify;\">Nesse treinamento voc&ecirc; aprender&aacute; como reconhecer as poss&iacute;veis raz&otilde;es de dores nas costas, como avaliar e, ap&oacute;s reconhecimento das poss&iacute;veis causas, como desenvolver o programa terap&ecirc;utico sugerido para sua melhora cl&iacute;nica. Voc&ecirc; tamb&eacute;m ter&aacute; o suporte especializado que o direcionar&aacute; a fazer uma avalia&ccedil;&atilde;o e terap&ecirc;utica mais efetiva.</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; tem &agrave; sua disposi&ccedil;&atilde;o a oportunidade de se beneficiar de um programa terap&ecirc;utico efetivo para suas dores cr&ocirc;nicas.</p>\r\n<p style=\"text-align: justify;\">Tome a decis&atilde;o correta, inscreva-se e comece j&aacute; o seu treinamento para uma vida mais feliz e sem dor.</p>', '2019-05-06', '2019-05-31', '<p>O que esperar do treinamento DORES NAS COSTAS NUNCA!</p>', '_parent', 1, NULL, '0', 'Eber Ortiz', 'https://pag.ae/7U-S3cDg6', 3, 3, 3, '2019-05-06 22:05:40', '2019-06-25 20:39:14'),
(7, 'Projeto 3', 'projeto-3', '1557174544.jpg', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema.&nbsp;<a title=\"Resumo\" href=\"https://codex.wordpress.org/pt-br:Resumo\" target=\"_blank\" rel=\"noopener\">Aprenda mais sobre resumos manuais.</a></p>', '2019-05-06', '2019-05-31', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema.&nbsp;<a title=\"Resumo\" href=\"https://codex.wordpress.org/pt-br:Resumo\" target=\"_blank\" rel=\"noopener\">Aprenda mais sobre resumos manuais.</a></p>', '_parent', 1, NULL, '0', 'Eber', NULL, 3, 4, 3, '2019-05-06 23:29:04', '2019-05-23 02:17:33'),
(8, 'Projeto 4', 'projeto-4', '1558403081.png', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema.&nbsp;</p>', '2019-05-06', '2019-05-25', '<p>Resumos s&atilde;o pequenas descri&ccedil;&otilde;es opcionais do conte&uacute;do do seu post feitas manualmente, que podem ser usadas em seu tema. ....</p>', '_parent', 1, NULL, '0', NULL, NULL, 4, 4, 3, '2019-05-06 23:29:36', '2019-05-21 04:44:41'),
(9, 'Olhos sempre saudáveis', 'olhos-sempre-saudaveis', '1558894771.jpg', '<p>Conteudo</p>', '2019-05-26', '2021-05-31', NULL, '_parent', 1, NULL, '0', NULL, 'https://pag.ae/7U--qmH-o', 4, 3, 3, '2019-05-26 21:19:31', '2019-06-24 19:22:37'),
(10, 'Saúde e Longevidade', 'saude-e-longevidade', '1561302198.jpg', '<p>Content</p>', '2019-06-06', '2020-06-30', '<p>Por qu&ecirc; e como ter mais sa&uacute;de e viver mais?<br />Como ter equil&iacute;brio emocional contra estresse e ansiedade?<br />Que habilidades devo desenvolver para conseguir sucesso e realiza&ccedil;&atilde;o pessoal e profissional?<br />Como sair do fracasso para o sucesso?<br />Essas e outras quest&otilde;es voc&ecirc; aprender&aacute; nesse Semin&aacute;rio. Esse conhecimento ir&aacute; revolucionar a sua vida.</p>', '_parent', 1, '/destaque/seminario-saude-e-longevidade', '1', 'Edson Barbosa', 'https://pag.ae/7U-S1icr3', 1, 5, 3, '2019-06-07 05:21:47', '2019-06-23 18:03:18'),
(11, 'Foque no sucesso', 'foque-no-sucesso', '1561300882.jpg', '<p><img src=\"http://prosaudeintegral.com.br/uploads/source/treinamentos/sucesso/fns-header.jpg\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<h4>O que esperar do treinamento FOQUE NO SUCESSO?</h4>\r\n<p><img src=\"http://prosaudeintegral.com.br/uploads/source/treinamentos/sucesso/passos.jpg\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<h2 style=\"text-align: center;\">Voc&ecirc; deseja ter sucesso na vida? sente que sua vida poderia ser mais?</h2>\r\n<p style=\"text-align: justify;\">Anseia por deixar sua marca no mundo e tem o desejo de fazer a diferen&ccedil;a atrav&eacute;s de uma vida com prop&oacute;sito?<br />Tem um sonho, mas n&atilde;o sabe por onde come&ccedil;ar, pois n&atilde;o se sentiu ainda empoderado o suficiente para dar o primeiro passo?<br />Voc&ecirc; sente bem l&aacute; dentro como se estivesse faltando algo, uma pe&ccedil;a chave para viver uma vida mais m&aacute;gica, repleta de motiva&ccedil;&atilde;o e entusiasmo?</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; v&ecirc; que o mundo est&aacute; avan&ccedil;ando e que voc&ecirc; est&aacute; ficando para tr&aacute;s?</p>\r\n<p style=\"text-align: justify;\">Voc&ecirc; quer sentir-se como v&iacute;tima das circunstancias ou quer avan&ccedil;ar com o mundo, criando as circunst&acirc;ncias para o seu sucesso, sendo a estrela principal em seu pr&oacute;prio filme? Ent&atilde;o, <strong>viva com prop&oacute;sito!</strong> Tenha um sonho em mente e realize-o em sua vida!</p>\r\n<h2 style=\"text-align: center;\"><em>&ldquo;As pessoas de maior resultado t&ecirc;m um forte prop&oacute;sito por tr&aacute;s de cada a&ccedil;&atilde;o em sua vida&rdquo;</em></h2>\r\n<h4 style=\"text-align: center;\"><strong>Todos os vision&aacute;rios s&atilde;o movidos por um prop&oacute;sito definido em suas vidas. </strong></h4>\r\n<h5 style=\"text-align: center;\"><strong><u>o prop&oacute;sito &eacute; a chave para a transforma&ccedil;&atilde;o</u></strong><strong>.</strong></h5>\r\n<p style=\"text-align: justify;\">O estudo acad&ecirc;mico te d&aacute; um conhecimento valioso, mas nunca te ensinou a pensar para o sucesso. Em casa, no trabalho e no meio de conviv&ecirc;ncia, voc&ecirc; n&atilde;o foi ensinado nem estimulado sobre prop&oacute;sito de vida e estrat&eacute;gias para ser uma pessoa de sucesso. Isso culmina com confus&atilde;o, frustra&ccedil;&atilde;o e fracasso. Por isso muitos n&atilde;o conseguem ser bem sucedidos na vida.</p>\r\n<p>Se voc&ecirc; &eacute; uma pessoa que:</p>\r\n<ul>\r\n<li>Gostaria de alterar radicalmente pelo menos uma &aacute;rea de sua vida.</li>\r\n<li>J&aacute; tentou fazer isso antes, mas n&atilde;o obteve os resultados desejados.</li>\r\n<li>N&atilde;o est&aacute; pronto para desistir de uma vida mais feliz e mais gratificante.</li>\r\n<li>Est&aacute; insatisfeito com sua situa&ccedil;&atilde;o atual e deseja mudar, mas n&atilde;o sabe como.</li>\r\n<li>Tem um sonho (conseguir algo ou ser algo) que deseja realizar.</li>\r\n<li>Se considera incapaz.</li>\r\n<li>Quer ser bem sucedido na vida.</li>\r\n</ul>\r\n<p><strong>Atrav&eacute;s desse treinamento voc&ecirc; ir&aacute; transformar todos os seus conceitos e vis&atilde;o de mundo.</strong></p>\r\n<p style=\"padding-left: 40px;\">Ent&atilde;o, o que voc&ecirc; realmente quer para sua vida?<br />N&atilde;o se contente com o que voc&ecirc; acha que pode conseguir ...<br />N&atilde;o deixe que o medo, a sobrecarga ou os maus h&aacute;bitos o impe&ccedil;am.<br />Essa &eacute; sua vida. E voc&ecirc; merece e pode ter o melhor.<br />Se voc&ecirc; acha que vai chegar onde quer por acaso, pense novamente.&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><strong>O </strong><strong>sucesso</strong><strong> n&atilde;o ocorre por acaso!</strong></p>\r\n<p style=\"text-align: justify;\">Atrav&eacute;s de um prop&oacute;sito definido e planos estrat&eacute;gicos bem elaborados voc&ecirc; adquirir&aacute; a autoconfian&ccedil;a e determina&ccedil;&atilde;o para criar a vida que voc&ecirc; realmente deseja, para perseguir seus maiores objetivos e assumir o controle de sua vida, experimentando a verdadeira satisfa&ccedil;&atilde;o de um viver com realiza&ccedil;&atilde;o plena.</p>\r\n<p style=\"text-align: justify;\">Com o treinamento <strong>FOQUE NO SUCESSO</strong> <strong>&ndash; O Segredo para a Realiza&ccedil;&atilde;o Pessoal e Profissional</strong>, voc&ecirc; ir&aacute; desvendar os segredos do potencial humano atrav&eacute;s de um estudo profundo da mente, como &eacute; que voc&ecirc; se torna o que pensa e caminha rumo a um prop&oacute;sito definido para uma vida cheia de significado e realiza&ccedil;&otilde;es! Esse treinamento ir&aacute; capacit&aacute;-lo com a compreens&atilde;o que voc&ecirc; precisa para implementar os conceitos ensinados para que voc&ecirc; possa atingir qualquer objetivo que voc&ecirc; realmente deseja.</p>\r\n<p>Como funciona o programa <strong>FOQUE NO SUCESSO?</strong></p>\r\n<p style=\"text-align: justify;\">O Programa <strong>FOQUE NO SUCESSO</strong> &eacute; um treinamento interativo de 06 meses projetado para ajud&aacute;-lo a entender e aplicar os princ&iacute;pios e conceitos que o levar&aacute; a descobrir o prop&oacute;sito de sua vida, seus sonhos e a desenvolver e maximizar as capacidades necess&aacute;rias para o sucesso. Com a aplica&ccedil;&atilde;o rigorosa em praticar esses princ&iacute;pios, voc&ecirc; experimentar&aacute; resultados incr&iacute;veis em todas as &aacute;reas de sua vida.</p>\r\n<p style=\"text-align: justify;\">Ao longo do treinamento voc&ecirc; conseguir&aacute; identificar os pensamentos do fracasso (h&aacute;bitos e cren&ccedil;as) que est&atilde;o impedindo voc&ecirc; de alcan&ccedil;ar os resultados que realmente deseja, em todas as &aacute;reas da sua vida. Aprender&aacute; a desenvolver pensamentos e atitudes que o conduzir&aacute; a subir os degraus do sucesso.</p>\r\n<p style=\"text-align: justify;\">N&oacute;s nos concentramos nas principais metas e objetivos que voc&ecirc; deseja alcan&ccedil;ar. Defina uma meta que seja digna de voc&ecirc; e n&oacute;s o orientaremos para sua realiza&ccedil;&atilde;o.</p>\r\n<p style=\"text-align: justify;\">Esse treinamento &eacute; uma combina&ccedil;&atilde;o estrategicamente projetada de educa&ccedil;&atilde;o, responsabilidade e a&ccedil;&atilde;o. A&ccedil;&atilde;o para a realiza&ccedil;&atilde;o progressiva de seus sonhos.</p>\r\n<p style=\"text-align: justify;\">Pensamos em tudo o que voc&ecirc; precisa para se concentrar no que realmente importa: o seu sucesso!</p>', '2019-06-07', '2020-06-30', '<p>Foco no sucesso</p>', '_parent', 1, NULL, '0', 'Edson Barbosa', 'https://pag.ae/7U-Rzpmw3\r\n', 1, 3, 3, '2019-06-07 19:47:46', '2019-06-23 17:41:22'),
(12, 'Treinamento Saúde e Longevidade', 'treinamento-saude-e-longevidade', '1561301848.jpg', '<p style=\"text-align: justify;\">Voc&ecirc; sente-se feliz e realizado com a sua condi&ccedil;&atilde;o de sa&uacute;de e de vida?</p>\r\n<p style=\"text-align: justify;\">Est&aacute; com problemas de sa&uacute;de?</p>\r\n<p style=\"text-align: justify;\">A sa&uacute;de &eacute; o bem mais precioso que podemos ter. Todos queremos chegar &agrave; terceira idade muito bem, com todas as fun&ccedil;&otilde;es corporais e cognitivas em perfeito equil&iacute;brio funcional.</p>\r\n<p style=\"text-align: justify;\">O fato &eacute; que a sa&uacute;de e longevidade n&atilde;o vem por acaso; &eacute; fruto de uma constru&ccedil;&atilde;o. Voc&ecirc; precisa querer ter sa&uacute;de e tem que estar disposto a pagar o pre&ccedil;o, desenvolvendo mudan&ccedil;as de h&aacute;bitos, determina&ccedil;&atilde;o e disciplina.</p>\r\n<p style=\"text-align: justify;\">O que voc&ecirc; quer construir para a sua velhice? Quer ter mais sa&uacute;de e longevidade? Ent&atilde;o, siga as seguintes orienta&ccedil;&otilde;es: &nbsp;</p>\r\n<p style=\"text-align: justify;\"><strong>Primeiro</strong>: se proponha a ser um idoso longevo cheio de sa&uacute;de, com todas as capacidades funcionais do corpo preservadas. Voc&ecirc; tem que ter esse objetivo bem fixo em sua mente;</p>\r\n<p style=\"text-align: justify;\"><strong>Segundo</strong>: saiba como exatamente est&aacute; a sua sa&uacute;de de forma sist&ecirc;mica, agora mesmo;</p>\r\n<p style=\"text-align: justify;\"><strong>Terceiro</strong>: crer que nunca &eacute; tarde para come&ccedil;ar. N&atilde;o importa como est&aacute; a sua sa&uacute;de, voc&ecirc; e s&oacute; voc&ecirc; pode mudar para melhor e come&ccedil;ar a construir o futuro que voc&ecirc; quer para si.</p>\r\n<p style=\"text-align: justify;\">O <strong>TREINAMENTO SA&Uacute;DE E LONGEVIDADE </strong>foi projetado pensando em ajuda-lo nas suas necessidades de sa&uacute;de nos aspectos f&iacute;sico, mental e emocional.</p>\r\n<p style=\"text-align: justify;\">O objetivo desse TREINAMENTO &eacute; proporcionar a voc&ecirc; subs&iacute;dios e condi&ccedil;&otilde;es para que o corpo consiga reagir sobre as disfun&ccedil;&otilde;es musculoesquel&eacute;ticas que geram dor e limita&ccedil;&otilde;es e problemas gerais de sa&uacute;de, tais como:</p>\r\n<ul style=\"text-align: justify;\">\r\n<li>An&aacute;lise diagn&oacute;stica da sa&uacute;de sist&ecirc;mica &ndash; important&iacute;ssimo, pois &eacute; a base para todo programa terap&ecirc;utico;</li>\r\n<li>Perfil alimentar de cada dia &ndash; o que voc&ecirc; come e como come definir&aacute; o est&aacute;gio de car&ecirc;ncias vitam&iacute;nicas e minerais e, consequentemente, a defini&ccedil;&atilde;o b&aacute;sica que justifica as poss&iacute;veis origens das doen&ccedil;as;</li>\r\n<li>o sistema gastrointestinal deficit&aacute;rio &eacute; muito frequente ap&oacute;s os 30 anos de idade, requerendo uma aten&ccedil;&atilde;o especial;</li>\r\n<li>Perfil emocional &ndash; uma mente estressada e ansiosa repercute sobre todo o corpo</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">Voc&ecirc; percebeu que esse treinamento funcionar&aacute; com consultas personalizadas, proporcionando as condi&ccedil;&otilde;es necess&aacute;rias para o corpo reagir, favorecendo-o para uma vida mais saud&aacute;vel e longeva.</p>\r\n<p style=\"text-align: justify;\">Visualize o futuro que voc&ecirc; quer para sua vida, sua sa&uacute;de e comece a constru&iacute;-lo agora mesmo.</p>\r\n<p style=\"text-align: center;\"><em>O futuro da sua sa&uacute;de e bem estar est&aacute; em suas m&atilde;os. <br />O que voc&ecirc; vai construir s&oacute; depende de voc&ecirc;.</em><br /><em>Inicie seu treinamento agora mesmo!</em></p>', '2019-06-15', '2020-06-30', NULL, '_parent', 1, NULL, '0', NULL, 'https://pag.ae/7U-S1icr3', 2, 3, 3, '2019-06-16 02:54:11', '2019-06-25 20:36:00'),
(13, 'VIVA COM PROPÓSITO', 'viva-com-proposito-2', '1560728580.jpg', '<p>Content</p>', '2019-06-16', '2020-06-30', '<p style=\"text-align: justify; font-size: 10pt;\"><em>Voc&ecirc; tem sonhos de sucesso? Voc&ecirc; tem um prop&oacute;sito em sua vida?&nbsp; </em><br /><em>N&atilde;o sabe como alcan&ccedil;ar seus sonhos e prop&oacute;sitos? Sente-se perdido?</em><br /><em>Sua vida em algum significado?</em> <em>Que legado voc&ecirc; pretende deixar para os seus?</em><br />Esse tema &ndash; <strong><em>viva com prop&oacute;sito</em></strong> - &eacute; essencial para todos aquele que deseja crescer, ser bem sucedido na vida e, acima de tudo, se preparar para transformar seus sonhos em realidade.<br />Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.<br /><em>Agende essa palestra para sua empresa</em></p>', '_parent', 1, NULL, '0', 'Edsson Barbosa', 'https://pag.ae/7U--cyBS8', 1, 6, 3, '2019-06-17 02:43:00', '2019-06-18 04:32:08'),
(14, 'FOQUE NO SUCESSO', 'foque-no-sucesso-2', '1560729543.jpg', '<p>O SUCESSO N&Atilde;O VEM POR ACASO OU POR SORTE; &Eacute; O RESULTADO DE PLANOS E ESTRAT&Eacute;GIAS BEM ELABORADOS!</p>\r\n<p>Todos almejam o sucesso nos relacionamentos, nos neg&oacute;cios e sentirem-se realizadas. Quais as estrat&eacute;gias para o sucesso e realiza&ccedil;&atilde;o pessoal e profissional?</p>\r\n<p>Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.</p>\r\n<p>Agende essa palestra para sua empresa</p>', '2019-06-16', '2020-06-30', '<p style=\"text-align: justify; font-size: 10pt;\">O SUCESSO N&Atilde;O VEM POR ACASO OU POR SORTE; &Eacute; O RESULTADO DE PLANOS E ESTRAT&Eacute;GIAS BEM ELABORADOS!<br />Todos almejam o sucesso nos relacionamentos, nos neg&oacute;cios e sentirem-se realizadas. Quais as estrat&eacute;gias para o sucesso e realiza&ccedil;&atilde;o pessoal e profissional?<br />Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.<br /><em>Agende essa palestra para sua empresa</em></p>', '_parent', 1, NULL, '0', 'Edsson Barvosa', 'https://pag.ae/7U--e2wxJ', 2, 6, 3, '2019-06-17 02:59:03', '2019-06-25 20:44:32'),
(15, 'SAÚDE E LONGEVIDADE', 'saude-e-longevidade-2', '1560729798.jpg', '<p><span style=\"font-size: 8pt;\">Ter vida longa e cheia de vitalidade &eacute; um desejo de todos. No entanto, 97% da popula&ccedil;&atilde;o ocidental chega aos 70 anos debilitado por doen&ccedil;as adquiridas ap&oacute;s os 50 anos.</span></p>\r\n<p><span style=\"font-size: 8pt;\">Por qu&ecirc; as pessoas est&atilde;o t&atilde;o doentes? Qual o segredo da longevidade? Por onde come&ccedil;ar? &Eacute; poss&iacute;vel reverter um quadro de doen&ccedil;as?</span></p>\r\n<p><span style=\"font-size: 8pt;\">Quais os h&aacute;bitos das pessoas longevas?</span></p>\r\n<p><span style=\"font-size: 8pt;\">Todos desejam chegar aos 120 anos, cheios de sa&uacute;de. Saiba que esse sonho &eacute; poss&iacute;vel, se voc&ecirc; se determinar a seguir os princ&iacute;pios que garantir&atilde;o mais sa&uacute;de e longevidade.</span></p>\r\n<p><span style=\"font-size: 8pt;\">Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.</span></p>\r\n<p><span style=\"font-size: 8pt;\">Agende essa palestra para sua empresa</span></p>', '2019-06-16', '2020-06-30', '<p style=\"text-align: justify; font-size: 10pt;\">Ter vida longa e cheia de vitalidade &eacute; um desejo de todos. No entanto, 97% da popula&ccedil;&atilde;o ocidental chega aos 70 anos debilitado por doen&ccedil;as adquiridas ap&oacute;s os 50 anos.<br /><em>Por qu&ecirc; as pessoas est&atilde;o t&atilde;o doentes? Qual o segredo da longevidade? Por onade come&ccedil;ar? &Eacute; poss&iacute;vel reverter um quadro de doen&ccedil;as? Quais os h&aacute;bitos das pessoas longevas?</em><br />Todos desejam chegar aos 120 anos, cheios de sa&uacute;de. Saiba que esse sonho &eacute; poss&iacute;vel, se voc&ecirc; se determinar a seguir os princ&iacute;pios que garantir&atilde;o mais sa&uacute;de e longevidade.<br />Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.<br /><em>Agende essa palestra para sua empresa</em></p>', '_parent', 1, '/destaque/seminario-saude-e-longevidade', '1', 'Edson Barbosa', 'https://pag.ae/7U--i8F2M', 3, 6, 3, '2019-06-17 03:03:18', '2019-06-24 19:26:13'),
(16, 'DORES NAS COSTAS NUNCA MAIS!', 'dores-nas-costas-nunca-mais', '1560814345.jpg', '<p>As dores cr&ocirc;nicas nas costas, que acompanham 50% das pessoas na fase produtiva, tem uma causa e sempre repercute sobre outros sistemas corporais, gerando problemas oculares, gastrite, intestino preso, dores referidas a dist&acirc;ncia, etc... Se negligenciada, o deixar&aacute; escravo de rem&eacute;dios e cirurgias. &Eacute; poss&iacute;vel eliminar a maioria dessas dores naturalmente!</p>\r\n<p>T&atilde;o importante quanto tratar &eacute; saber as poss&iacute;veis causas e m&eacute;todos preventivos, seja no trabalho ou nas atividades de vida di&aacute;ria.</p>\r\n<p>Essa palestra conscientiza sobre as v&aacute;rias causas e m&eacute;todos preventivos.</p>\r\n<p>Quem sente dores cr&ocirc;nicas sabe da import&acirc;ncia desse tema.</p>\r\n<p>Agende essa palestra para sua empresa</p>', '2019-06-17', '2020-06-30', '<p style=\"text-align: justify; font-size: 13px;\">As dores cr&ocirc;nicas nas costas, que acompanham 50% das pessoas na fase produtiva, tem uma causa e sempre repercute sobre outros sistemas corporais, gerando problemas oculares, gastrite, intestino preso, dores referidas a dist&acirc;ncia, etc... Se negligenciada, o deixar&aacute; escravo de rem&eacute;dios e cirurgias. &Eacute; poss&iacute;vel eliminar a maioria dessas dores naturalmente!<br />T&atilde;o importante quanto tratar &eacute; saber as poss&iacute;veis causas e m&eacute;todos preventivos, seja no trabalho ou nas atividades de vida di&aacute;ria.<br />Essa palestra conscientiza sobre as v&aacute;rias causas e m&eacute;todos preventivos.<br />Quem sente dores cr&ocirc;nicas sabe da import&acirc;ncia desse tema.<br /><em>Agende essa palestra para sua empresa</em></p>', '_parent', 1, NULL, '0', NULL, 'https://pag.ae/7U--oz7YJ', 4, 6, 3, '2019-06-18 02:32:25', '2019-06-24 19:25:23'),
(17, 'Qualidade de vida e produtividade', 'qualidade-de-vida-e-produtividade', '1560820603.jpg', '<p><span style=\"font-size: 13px;\">O n&iacute;vel de qualidade de vida tem total rela&ccedil;&atilde;o com a sa&uacute;de e produtividade no trabalho e atividades di&aacute;rias.</span></p>\r\n<p><span style=\"font-size: 13px;\">Como desenvolver mais qualidade de vida, mesmo diante da correria do dia? &Eacute; poss&iacute;vel se programar para ter mais sa&uacute;de e ter mais disposi&ccedil;&atilde;o para desenvolver melhor as atividades profissionais?</span></p>\r\n<p><span style=\"font-size: 13px;\">Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.</span></p>\r\n<p><span style=\"font-size: 13px;\">Agende essa palestra para sua empresa</span></p>', '2019-06-17', '2020-06-30', '<p><span style=\"font-size: 13px;\">O n&iacute;vel de qualidade de vida tem total rela&ccedil;&atilde;o com a sa&uacute;de e produtividade no trabalho e atividades di&aacute;rias.<br /></span><span style=\"font-size: 13px;\">Como desenvolver mais qualidade de vida, mesmo diante da correria do dia? &Eacute; poss&iacute;vel se programar para ter mais sa&uacute;de e ter mais disposi&ccedil;&atilde;o para desenvolver melhor as atividades profissionais?<br /></span><span style=\"font-size: 13px;\">Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.<br /></span><span style=\"font-size: 13px;\">Agende essa palestra para sua empresa</span></p>', '_parent', 1, NULL, '0', NULL, 'https://pag.ae/7U--pzYQo', 5, 6, 3, '2019-06-18 04:16:43', '2019-06-24 19:24:41'),
(18, '+ VISÃO – OLHOS SEMPRE SAUDÁVEIS', 'visao-olhos-sempre-saudaveis', '1560820803.jpg', '<p>&Eacute; poss&iacute;vel melhorar seus problemas de vis&atilde;o? &Eacute; poss&iacute;vel sim, e naturalmente. S&oacute; depender&aacute; de voc&ecirc;! Este tema ensinar&aacute; voc&ecirc; a ter uma vis&atilde;o mais saud&aacute;vel, mesmo em condi&ccedil;&otilde;es cl&iacute;nicas desfavor&aacute;veis.</p>\r\n<p>35 milh&otilde;es de brasileiros sofrem com problemas visuais, com estat&iacute;sticas desastrosas pela frente, e solu&ccedil;&otilde;es nada boas oferecidas pelos m&eacute;todos tradicionais no mundo.</p>\r\n<p>Adultos, jovens, crian&ccedil;as, idosos, todos com um risco tremendo de perderem a vis&atilde;o; e n&oacute;s disponibilizamos essa maravilha de solu&ccedil;&atilde;o natural para que voc&ecirc; possa enxergar e viver melhor.</p>', '2019-06-17', '2020-06-30', '<p style=\"text-align: justify;\"><span style=\"font-size: 13px;\">&Eacute; poss&iacute;vel melhorar seus problemas de vis&atilde;o? &Eacute; poss&iacute;vel sim, e naturalmente. S&oacute; depender&aacute; de voc&ecirc;! Este tema ensinar&aacute; voc&ecirc; a ter uma vis&atilde;o mais saud&aacute;vel, mesmo em condi&ccedil;&otilde;es cl&iacute;nicas desfavor&aacute;veis.<br /></span><span style=\"font-size: 13px;\">35 milh&otilde;es de brasileiros sofrem com problemas visuais, com estat&iacute;sticas desastrosas pela frente, e solu&ccedil;&otilde;es nada boas oferecidas pelos m&eacute;todos tradicionais no mundo.<br /></span><span style=\"font-size: 13px;\">Adultos, jovens, crian&ccedil;as, idosos, todos com um risco tremendo de perderem a vis&atilde;o; e n&oacute;s disponibilizamos essa maravilha de solu&ccedil;&atilde;o natural para que voc&ecirc; possa enxergar e viver melhor.</span></p>', '_parent', 1, NULL, '0', NULL, 'https://pag.ae/7U--qmH-o', 6, 6, 3, '2019-06-18 04:20:03', '2019-06-24 19:24:59'),
(19, 'Desenvolvimento pessoal e sucesso profissional', 'desenvolvimento-pessoal-e-sucesso-profissional', '1560821093.jpg', '<p style=\"text-align: justify;\"><span style=\"font-size: 13px;\">Todos querem ser bem sucedidos, mas o sucesso s&oacute; vem para os que est&atilde;o preparados. S&atilde;o potencialidades essenciais, mudan&ccedil;a de h&aacute;bitos e muita determina&ccedil;&atilde;o. Essas potencialidades podem ser&nbsp; desenvolvidas por todos que se determinam a seguir determinados princ&iacute;pios e&nbsp; ren&uacute;ncias. Para aqueles que desenvolvem essas potencialidades o sucesso &eacute; uma realidade.</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 13px;\">Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.</span></p>\r\n<p><span style=\"font-size: 13px;\">Agende essa palestra para sua empresa</span></p>', '2019-06-17', '2020-06-30', '<p style=\"text-align: justify;\"><span style=\"font-size: 13px;\">Todos querem ser bem sucedidos, mas o sucesso s&oacute; vem para os que est&atilde;o preparados. S&atilde;o potencialidades essenciais, mudan&ccedil;a de h&aacute;bitos e muita determina&ccedil;&atilde;o. Essas potencialidades podem ser&nbsp; desenvolvidas por todos que se determinam a seguir determinados princ&iacute;pios e&nbsp; ren&uacute;ncias. Para aqueles que desenvolvem essas potencialidades o sucesso &eacute; uma realidade.<br /></span><span style=\"font-size: 13px;\">Tudo isso e muito mais voc&ecirc; aprender&aacute; nessa magn&iacute;fica palestra.<br /></span><em><span style=\"font-size: 13px;\">Agende essa palestra para sua empresa</span></em></p>', '_parent', 1, NULL, '0', NULL, 'https://pag.ae/7U--s3a9r', 7, 6, 3, '2019-06-18 04:24:53', '2019-06-25 20:48:20'),
(20, 'NATUROPÁTICA', 'naturopatica', '1560910282.jpg', '<p style=\"text-align: justify;\">Vivemos em u cen&aacute;rio de pessoas doentes. Ap&oacute;s os 35 anos todos j&aacute; come&ccedil;am a se preocupar por sentirem o corpo reclamando atrav&eacute;s de sintomas indicativos de que algo est&aacute; errado. A popula&ccedil;&atilde;o ocidental, principalmente, sofre de in&uacute;meros dist&uacute;rbios org&acirc;nicos ocasionados por h&aacute;bitos e estilo de vida inadequados. As consequ&ecirc;ncias sempre s&atilde;o: doen&ccedil;as degenerativas, problemas cardiovasculares, gastrointestinais e nervoso, estresse, ansiedade, alergias, tens&atilde;o pr&eacute;-menstrual, dores menstruais, anemia, artrite, diabetes, c&acirc;ncer, constipa&ccedil;&otilde;es, bronquite, candid&iacute;ase, enxaquecas, sinusite, menopausa, osteoporose,</p>\r\n<p style=\"text-align: justify;\">cistite, obesidade, problemas de pele, afe&ccedil;&otilde;es digestivas, &uacute;lceras, obstipa&ccedil;&atilde;o, eczema e outras doen&ccedil;as de pele, irrita&ccedil;&otilde;es do c&oacute;lon, s&iacute;ndrome do c&oacute;lon irrit&aacute;vel, e outras.</p>\r\n<p style=\"text-align: justify;\">A&nbsp;Naturopatia &eacute; um sistema de tratamento que utiliza recursos naturais para ajudar o corpo a atingir equil&iacute;brio da sua sa&uacute;de f&iacute;sica, mental e emocional, curando-se a si pr&oacute;prio. A&nbsp;<strong>Naturopatia</strong>&nbsp;&eacute;, antes de tudo, um processo educativo, tanto preventivo quanto reequilibrador, no que diz respeito ao tratamento dos dist&uacute;rbios j&aacute; instalados no organismo.</p>\r\n<p style=\"text-align: justify;\">A procura por essa metodologia curativa adquire a cada dia mais adeptos, haja vista a medicina convencional focar apenas em rem&eacute;dios e/ou cirurgias. Sabemos o ser humano &eacute; muito mais!</p>\r\n<p style=\"text-align: justify;\">O Consultor Naturopata ajudar&aacute; voc&ecirc; a desenvolver um verdadeiro processo de cura. Comece agora mesmo essa jornada de sa&uacute;de e longevidade.</p>\r\n<div class=\"container pricing pb-5\">\r\n<div class=\"row flex-items-xs-middle flex-items-xs-center\"><!-- Table #1  -->\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-success pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>200,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">SESS&Atilde;O INICIAL AVULSA</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total por sess&atilde;o: R$ 200,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-S78j2P\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<!-- Table #1  -->\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-info pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>180,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 5 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 900,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-S9sYxJ\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<!-- Table #1  -->\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-warning pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>160,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 10 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 1600,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-Sa2dHL\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', '2019-06-18', '2020-06-30', '<p style=\"text-align: justify;\">A Naturopatia utiliza as for&ccedil;as curativas naturais presentes no corpo humano em conjunto com a nutri&ccedil;&atilde;o e, por vezes, suplementos naturais de diferentes formas e origens.</p>\r\n<p style=\"text-align: justify;\">Objetiva evitar e tratar doen&ccedil;as adquiridas por h&aacute;bitos e estilo de vida inadequados, tais como: quadros degenerativos, al&eacute;rgicos, gastrointestinais, diabetes, osteoporose e outros.</p>\r\n<p style=\"text-align: justify;\">Veja os passos para fazer atendimento on-line</p>', '_parent', 1, NULL, '0', NULL, NULL, 1, 7, 3, '2019-06-19 05:11:22', '2019-06-27 03:26:56');
INSERT INTO `posts` (`id`, `title`, `slug`, `image`, `content`, `date_start`, `date_end`, `description`, `target`, `status`, `external_url`, `redirect`, `author`, `payment_link`, `order`, `category_id`, `user_id`, `created_at`, `updated_at`) VALUES
(21, 'ERGONÔMICA', 'ergonomica', '1560985419.jpg', '<p style=\"text-align: justify;\"><strong>ERGON&Ocirc;MICA</strong></p>\r\n<p style=\"text-align: justify;\">As dores cr&ocirc;nicas, principalmente dores lombares, s&atilde;o a maior causa de falta ao trabalho no Brasil. &Eacute; muito importante compreender as poss&iacute;veis causas das dores e, acima de tudo, como tratar. Na maioria dos casos a dor nas costas &eacute; tratada de forma satisfat&oacute;ria com orienta&ccedil;&otilde;es posturais nas atividades de cada dia em casa ou o trabalho, orienta&ccedil;&otilde;es ergon&ocirc;micas nas atividades do trabalho e exerc&iacute;cios terap&ecirc;uticos.</p>\r\n<p style=\"text-align: justify;\">Os fatores causais s&atilde;o multifatoriais, tais como: h&eacute;rnia de disco, muscular, nervo ci&aacute;tico, posturais, degenerativos, viscerais, dentre outros.</p>\r\n<p style=\"text-align: justify;\">A Ergonomia objetiva o gerenciamento de dores cr&ocirc;nicas corporais, principalmente a n&iacute;vel de coluna vertebral. Utilizamos os recursos das Terapias Manuais, priorizando a <strong>AVALIA&Ccedil;&Atilde;O</strong> e o <strong>DIAGN&Oacute;STICO</strong> objetivando determinar as condutas <strong>TERAP&Ecirc;UTICAS</strong> mais eficazes no&nbsp;combate &agrave; dor e para o reajuste posicional corporal.</p>\r\n<p style=\"text-align: justify;\">Pessoas que sofrem dores no corpo por anos, escravizadas por rem&eacute;dios que nada resolvem, poder&atilde;o encontrar a solu&ccedil;&atilde;o para seus problemas dolorosos atrav&eacute;s das Terapias Manuais.</p>\r\n<p style=\"text-align: justify;\">O tratamento com <strong>Terapias Manuais</strong> tem sido eficaz nas disfun&ccedil;&otilde;es cl&iacute;nicas relacionadas &agrave;s seguintes situa&ccedil;&otilde;es:</p>\r\n<p style=\"text-align: justify;\"><strong>Dores e desvios da coluna vertebral</strong></p>\r\n<ul style=\"text-align: justify;\">\r\n<li>Lombalgia</li>\r\n<li>Ci&aacute;ticas</li>\r\n<li>lombociatalgia</li>\r\n<li>Cervicalgia</li>\r\n<li>cervicobraquialgia</li>\r\n<li>H&eacute;rnias de disco</li>\r\n<li>Escoliose</li>\r\n<li>Hipercifose</li>\r\n<li>Hiperlordose</li>\r\n<li>Espondilolistese</li>\r\n<li>Espondiloartrose</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">&nbsp;<strong>Processos Inflamat&oacute;rios e dolorosos dos tecidos moles</strong></p>\r\n<ul style=\"text-align: justify;\">\r\n<li>Bursites</li>\r\n<li>Dores e tens&otilde;es Musculares</li>\r\n<li>Artrite Reumat&oacute;ide</li>\r\n<li>Encurtamentos miofasciais</li>\r\n<li>Fibromialgia</li>\r\n<li>Libera&ccedil;&otilde;es cicatriciais p&oacute;s-cir&uacute;rgicas</li>\r\n</ul>\r\n<p style=\"text-align: justify;\"><strong>Disfun&ccedil;&otilde;es sist&ecirc;micas envolvendo ossos, m&uacute;sculos e nervos</strong></p>\r\n<ul style=\"text-align: justify;\">\r\n<li>Artrose</li>\r\n<li>Bico papagaio</li>\r\n<li>Osteoporose</li>\r\n<li>Dores de cabe&ccedil;a (faciais, couro cabeludo e/ou &aacute;rea da nuca)</li>\r\n<li>Enxaqueca</li>\r\n<li>Polineuropatias</li>\r\n<li>Neuropatia diab&eacute;tica</li>\r\n<li>Disfun&ccedil;&otilde;es Viscerais\r\n<ul style=\"text-align: justify;\">\r\n<li>hipersensibilidade visceral</li>\r\n<li>libera&ccedil;&otilde;es cicatriciais p&oacute;s cir&uacute;rgicas</li>\r\n<li>C&oacute;licas menstruais&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n</li>\r\n<li>Sequelas de Derrame cerebral</li>\r\n<li>Edemas nas extremidades</li>\r\n<li>Treino proprioceptivo para preven&ccedil;&atilde;o de quedas no idoso</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">A consultoria ergon&ocirc;mica ajudar&aacute; voc&ecirc; a desenvolver um verdadeiro processo de reorganiza&ccedil;&atilde;o estrutural e funcional do corpo, levando-o ao al&iacute;vio de seu quadro doloroso.</p>\r\n<p style=\"text-align: justify;\">Comece agora mesmo essa jornada de restaura&ccedil;&atilde;o da sa&uacute;de.</p>\r\n<div class=\"container pricing pb-5\">\r\n<div class=\"row flex-items-xs-middle flex-items-xs-center\">\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-success pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>200,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">SESS&Atilde;O INICIAL AVULSA</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total por sess&atilde;o: R$ 200,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-SbwwTM\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-info pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>180,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 5 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 900,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-ScvPKo\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-warning pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>160,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 10 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 1600,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-SxbAHL\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', '2019-06-19', '2020-06-30', '<p style=\"text-align: justify;\">A Ergonomia objetiva o gerenciamento de dores cr&ocirc;nicas corporais, principalmente a n&iacute;vel de coluna vertebral. As dores cr&ocirc;nicas s&atilde;o os principais fatores limitantes na realiza&ccedil;&atilde;o de atividades laborais no trabalho e no lar. Sua aplica&ccedil;&atilde;o na empresa minimiza quadro &aacute;lgico, aumenta produtividade e motiva&ccedil;&atilde;o no trabalho.</p>', '_parent', 1, NULL, '0', NULL, NULL, 2, 7, 3, '2019-06-20 02:03:39', '2019-06-27 03:28:20'),
(22, 'PSICOLÓGICA', 'psicologica', '1560987421.jpg', '<p style=\"text-align: justify;\"><strong>PSICOL&Oacute;GICA</strong></p>\r\n<p style=\"text-align: justify;\">Muitas situa&ccedil;&otilde;es podem gerar desequil&iacute;brios emocionais, dentre essas consta a ansiedade, considerada o mal do s&eacute;culo.</p>\r\n<p style=\"text-align: justify;\">Estresse intenso e ansiedade desestabilizam m&uacute;ltiplos sistemas corporais, sendo fator origin&aacute;rio de doen&ccedil;as psicossom&aacute;ticas.</p>\r\n<p style=\"text-align: justify;\">Muitos desequil&iacute;brios mentais requerem aten&ccedil;&atilde;o especializada, dentre eles est&atilde;o:</p>\r\n<ul style=\"text-align: justify;\">\r\n<li><em>Transtorno D&eacute;ficit de Aten&ccedil;&atilde;o</em></li>\r\n<li><em>Transtorno Obsessivo Compulsivo</em></li>\r\n<li>Transtornos alimentares</li>\r\n<li>Crises vitais ( puberdade, adolesc&ecirc;ncia, vida adulta, envelhecimento)</li>\r\n<li>Crises&nbsp;existenciais</li>\r\n<li>P&acirc;nico</li>\r\n<li>Estresse / estresse p&oacute;s-traum&aacute;tico</li>\r\n<li><em>Prepara&ccedil;&atilde;o para Concursos</em></li>\r\n<li><em>Prepara&ccedil;&atilde;o para Vestibular</em></li>\r\n<li><em>Aliena&ccedil;&atilde;o Parental</em></li>\r\n<li><em>Prepara&ccedil;&atilde;o para Aposentadoria</em></li>\r\n<li><em>Fobias</em></li>\r\n<li><em>Ansiedade</em></li>\r\n<li><em>Depress&atilde;o</em></li>\r\n<li>Transtorno Bipolar</li>\r\n<li>Transtorno dissociativo;</li>\r\n<li>Transtornos personalidade / borderline / esquiz&oacute;ide paran&oacute;ide;</li>\r\n<li><em>Melancolia</em></li>\r\n<li><em>V&iacute;cios</em></li>\r\n<li><em>Dist&uacute;rbios de Sono</em></li>\r\n<li>Quest&otilde;es de <em>G&ecirc;nero</em></li>\r\n<li><em>Problemas na Aprendizagem</em></li>\r\n<li><em>Sexualidade</em></li>\r\n<li><em>Relacionamentos</em></li>\r\n<li><em>Prepara&ccedil;&atilde;o Psicol&oacute;gica para eventos importantes</em></li>\r\n</ul>\r\n<ul style=\"text-align: justify;\">\r\n<li>Sentimentos desagrad&aacute;veis frequentes (raiva, tristeza, medo, ang&uacute;stia, ansiedade, m&aacute;goa)</li>\r\n<li>Luto pela morte de algu&eacute;m ou por alguma perda significativa (desemprego, div&oacute;rcio)</li>\r\n<li>Dificuldade de relacionamento interpessoal</li>\r\n<li>Dificuldades pessoais como timidez, baixa autoestima, impulsividade</li>\r\n<li>Necessidade de orienta&ccedil;&atilde;o sobre educa&ccedil;&atilde;o de filhos</li>\r\n<li>Necessidade de orienta&ccedil;&atilde;o pr&eacute;-matrimonial (namoro, noivado e relacionamentos amorosos)</li>\r\n<li>Problemas de relacionamento pessoais / interpessoais/ conjugais / familiares / grupais</li>\r\n<li>Outra situa&ccedil;&atilde;o que esteja comprometendo seu bem-estar emocional</li>\r\n<li>Emiss&atilde;o de Laudos Psicol&oacute;gicos e Pareceres cl&iacute;nicos.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">A consultoria Psicol&oacute;gica ajudar&aacute; voc&ecirc; a desenvolver um verdadeiro processo de reequil&iacute;brio emocional. O corpo agradece.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<div class=\"container pricing pb-5\">\r\n<div class=\"row flex-items-xs-middle flex-items-xs-center\">\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-success pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>100,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">SESS&Atilde;O INICIAL AVULSA</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total por sess&atilde;o: R$ 100,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-Su_rCM\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-info pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>90,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 5 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 450,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-Syjrg6\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-warning pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>80,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 10 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 800,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-Sz2c66\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', '2019-06-19', '2020-06-30', '<p style=\"text-align: justify;\">A consultoria psicol&oacute;gica&nbsp;&eacute; indicada para todas as&nbsp;pessoas que procuram&nbsp;aumentar sua perf&oacute;mance ps&iacute;quica e emocional, tais como: estresse, ansiedade ou desequil&iacute;brios emocionais que requerem acompanhamento mais intensivo.</p>', '_parent', 1, NULL, '0', NULL, NULL, 3, 7, 3, '2019-06-20 02:37:01', '2019-06-27 03:39:15'),
(23, 'DESENVOLVIMENTO PESSOAL E PROFISSIONAL', 'desenvolvimento-pessoal-e-profissional', '1560988266.jpg', '<p style=\"text-align: justify;\"><strong>DESENVOLVIMENTO PESSOAL E PROFISSIONAL</strong></p>\r\n<p style=\"text-align: justify;\">Todo mundo tem algum tipo de objetivo ou de sonho. Todo mundo quer ter uma boa casa, carro, um corpo mais bonito e saud&aacute;vel ou at&eacute; mesmo o emprego dos sonhos e ser completamente realizado. Se voc&ecirc;&nbsp;ainda n&atilde;o conseguiu seu objetivo ou sonho &eacute; porque est&aacute; faltando alguma coisa. &Eacute; muito tentador querer ter o que se deseja; no entanto, antes de querer ter &eacute; preciso ser. Voc&ecirc; deve sempre se perguntar o que voc&ecirc; precisa ser para que tudo isso aconte&ccedil;a de maneira f&aacute;cil. Atrav&eacute;s do desenvolvimento pessoal&nbsp;voc&ecirc; come&ccedil;a a pensar sobre quem voc&ecirc; deve se tornar e quais s&atilde;o os conhecimentos, as habilidades e os comportamentos que &eacute; preciso adquirir ou alterar para voc&ecirc; conseguir realizar aquilo que voc&ecirc; quer.</p>\r\n<p style=\"text-align: justify;\">Se voc&ecirc; &eacute; um empres&aacute;rio, por exemplo, pense em&nbsp;quem voc&ecirc; deve se tornar e quais s&atilde;o as novas habilidades de ger&ecirc;ncia, de gest&atilde;o, de processos ou finan&ccedil;as que voc&ecirc; deve adquirir para levar o seu neg&oacute;cio para um pr&oacute;ximo n&iacute;vel.&nbsp;Enquanto voc&ecirc; n&atilde;o conseguir perceber quais s&atilde;o os seus comportamentos que n&atilde;o est&atilde;o de acordo com a realiza&ccedil;&atilde;o do seu sonho, fica muito dif&iacute;cil voc&ecirc; se transformar no tipo de pessoa preparada para atingir a sua meta pessoal.</p>\r\n<p style=\"text-align: justify;\">O ponto principal n&atilde;o &eacute;&nbsp;simplesmente atingir a meta,&nbsp;<strong>mas como atingir uma meta de maneira sustent&aacute;vel</strong>. Isso tem que virar um h&aacute;bito e se manter na sua&nbsp;vida. Para conseguir isso &eacute; preciso fazer um tipo de Upgrade. Como? Atrav&eacute;s de a&ccedil;&otilde;es! O conceito &eacute; simples: primeiro voc&ecirc; precisa ser, depois fazer, para no fim ter.&nbsp;A partir do momento que voc&ecirc; muda seus paradigmas e visualiza o que deseja ser, facilmente pode ter aquilo que voc&ecirc; almeja e, suas novas a&ccedil;&otilde;es gerar&aacute; resultados mais satisfat&oacute;rios.</p>\r\n<h4 style=\"text-align: center;\"><strong>A consultoria de desenvolvimento pessoal levar&aacute; a um pr&oacute;ximo n&iacute;vel na defini&ccedil;&atilde;o de objetivos que almeja alcan&ccedil;ar e como se preparar para alcan&ccedil;&aacute;-lo e o ajudar&aacute; </strong><strong>a encontrar o seu potencial m&aacute;ximo para o sucesso pessoal e profissional.</strong></h4>\r\n<!--Desenvolvimento-->\r\n<div class=\"container pricing pb-5\">\r\n<div class=\"row flex-items-xs-middle flex-items-xs-center\">\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-success pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>400,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">CONSULTORIA AVULSA</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total por sess&atilde;o: R$ 400,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-SA4Xpo\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-info pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>300,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 5 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 1.500,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-SCnZg5\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-warning pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>250,00<span class=\"period\"> /Valor da sess&atilde;o</span></h3>\r\n</div>\r\n<div class=\"card-block\">\r\n<h5 class=\"card-title\">PACOTE DE 10 SESS&Otilde;ES</h5>\r\n<div class=\"dropdown-divider\">&nbsp;</div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">Total do pacote: R$ 2.500,00</li>\r\n</ul>\r\n<p>Todos os servi&ccedil;os podem ser parcelados no cart&atilde;o de cr&eacute;dito via pagseguro em at&eacute; 12x.</p>\r\n<a class=\"btn btn-gradient mt-2\" href=\"https://pag.ae/7U-SD_yr3\" target=\"_blank\" rel=\"noopener\">ADQUIRIR</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', '2019-06-19', '2020-06-30', '<p style=\"text-align: justify;\">A consultoria de desenvolvimento pessoal ajuda-o a encontrar o seu potencial m&aacute;ximo como indiv&iacute;duo, fato fundamental para o crescimento da empresa. Funcion&aacute;rios capacitados geram melhores resultados.<br />Quer ser bem sucedido? Tenha uma defini&ccedil;&atilde;o clara de objetivo, metas, planejamento e autoconhecimento.&nbsp; Certamente voc&ecirc; ser&aacute; mais competitivo, estar&aacute; em posi&ccedil;&atilde;o de destaque na empresa e poder&aacute; receber uma inevit&aacute;vel promo&ccedil;&atilde;o na empresa.</p>', '_parent', 1, NULL, '0', NULL, NULL, 4, 7, 3, '2019-06-20 02:51:06', '2019-06-25 20:56:35'),
(24, 'Livro dores nas costas nunca mais', 'livro-dores-nas-costas-nunca-mais', '1561594056.jpg', '<p><img src=\"https://prosaudeintegral.com.br/uploads/source/treinamentos/comense-a-vivir.jpg\" alt=\"\" width=\"100%\" height=\"auto\" /><img src=\"http://127.0.0.1:8000/uploads/source/treinamentos/Imagem3.png\" alt=\"\" width=\"100%\" height=\"auto\" /></p>\r\n<div class=\"card p-4\">\r\n<p style=\"text-align: justify;\">Se h&aacute; uma coisa que rouba a nossa alegria e sa&uacute;de s&atilde;o as dores corporais. <br />&Eacute; interessante como afeta 90% das pessoas em fase produtiva! <br />Os fatores causadores s&atilde;o variados:</p>\r\n<ul class=\"pl-4 pr-4\" style=\"text-align: justify;\">\r\n<li>Estresse,</li>\r\n<li>Posturas incorretas</li>\r\n<li>Obesidade</li>\r\n<li>Idade</li>\r\n<li>Sedentarismo...</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">O fato &eacute; que a maioria das pessoas n&atilde;o sabe como amenizar o sofrimento, e vira um ciclo vicioso de dor - rem&eacute;dio - ins&ocirc;nia - estresse. Rem&eacute;dios s&atilde;o apenas paliativos ilus&oacute;rios. Al&eacute;m de n&atilde;o resolverem o problema, cronifica o quadro doloroso e intoxica o corpo. Conhecer como funciona a din&acirc;mica corporal &eacute; fundamental no trajeto de resolu&ccedil;&atilde;o das dores musculares e esquel&eacute;ticas.</p>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div class=\"card pt-3 mb-3\">\r\n<div class=\"row no-gutters align-items-center\">\r\n<div class=\"col-md-8\">\r\n<div class=\"card-body\">\r\n<h5 class=\"card-title\">O que voc&ecirc; encontrar&aacute; nesse Manual?</h5>\r\n<ul>\r\n<li>Conhecer&aacute; como funciona a coluna vertebral e sua inter-rela&ccedil;&atilde;o com outros &oacute;rg&atilde;os e sistemas corporais;</li>\r\n<li>Aprender&aacute; a identificar as poss&iacute;veis causas originadoras de dores nas costas;</li>\r\n<li>A rela&ccedil;&atilde;o dos padr&otilde;es posturais e as dores cr&ocirc;nicas;</li>\r\n<li>Por qu&ecirc; a obesidade, estresse e gestantes evoluem com dores nas costas;</li>\r\n<li>A import&acirc;ncia de posturas corretas nas atividades do lar e do trabalho;</li>\r\n<li>Os cuidados redobrados na terceira idade;</li>\r\n<li>S&atilde;o dezenas de orienta&ccedil;&otilde;es, exemplificadas atrav&eacute;s de imagens fotogr&aacute;ficas, para que voc&ecirc; possa se livrar de suas dores.</li>\r\n</ul>\r\n<p class=\"card-text\">&nbsp;</p>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4\"><img class=\"card-img\" src=\"https://res.cloudinary.com/prosaudeintegral/image/upload/v1560993671/psi/Imagem9_xl3t45.png\" alt=\"Sem dor\" width=\"100%\" height=\"auto\" /></div>\r\n</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div class=\"card bg-light mb-3 text-center\">\r\n<div class=\"card-header h2\">Esse Manual Dores nas Costas Nunca Mais! <br />servir&aacute; de grande norteador para que voc&ecirc; seja mais feliz sem dor.</div>\r\n</div>\r\n<div class=\"row pt-4 justify-content-center align-items-center\">\r\n<div class=\"col-xs-12 col-md-5 text-center\"><a class=\"btn btn-primary btn-lg text-white\" title=\"LIVRO\" href=\"https://pag.ae/7UYP_c3hN\" target=\"_blank\" rel=\"noopener\">ADQUIRIR <br /></a>\r\n<h4>LIVRO</h4>\r\n</div>\r\n</div>', '2019-06-25', '2020-06-30', '<p>Se h&aacute; uma coisa que rouba a nossa alegria e sa&uacute;de s&atilde;o as dores corporais. <br />&Eacute; interessante como afeta 90% das pessoas em fase produtiva! <br />Os fatores causadores s&atilde;o variados:</p>', '_parent', 1, NULL, '0', NULL, NULL, 1, 8, 3, '2019-06-25 21:58:07', '2019-06-27 03:07:36'),
(25, 'Clube de Vantagens', 'clube-de-vantagens', '1561983253.jpg', '<p style=\"text-align: justify;\">Para a Pr&oacute;-Sa&uacute;de Integral cuidar das pessoas &eacute; mais do que oferecer atendimento e servi&ccedil;os de qualidade, &eacute; proporcionar uma solu&ccedil;&atilde;o completa em sa&uacute;de integral, abrangendo os problemas relacionados a sa&uacute;de f&iacute;sica e mental, bem como o desenvolvimento pessoal.</p>\r\n<p style=\"text-align: justify;\">Nossa filosofia &eacute; poder suprir suas necessidades de sa&uacute;de e desenvolvimento pessoal de forma acess&iacute;vel e flex&iacute;vel.</p>\r\n<p style=\"text-align: justify;\">O Clube de Vantagens Pr&oacute;-Sa&uacute;de Integral possibilita a voc&ecirc; acessibilidade a m&uacute;ltiplos servi&ccedil;os e produtos, com descontos especiais, durante per&iacute;odo de vig&ecirc;ncia contratual.</p>\r\n<p style=\"text-align: justify;\">Servi&ccedil;os como: consultas, cursos e treinamentos de sa&uacute;de e desenvolvimento pessoal ser&atilde;o disponibilizados com descontos de at&eacute; 50% sobre valor divulgado. A melhor parte &eacute; que todos os servi&ccedil;os est&atilde;o dispon&iacute;veis on-line, onde todas as suas necessidades s&atilde;o supridas sem precisar sair de casa.</p>\r\n<p style=\"text-align: justify;\">Como participar do clube de vantagens?</p>\r\n<p style=\"text-align: justify;\">1&ordm; Passo &ndash; realize seu cadastro</p>\r\n<p style=\"text-align: justify;\">2&ordm; Passo &ndash; realize a compra aqui&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p style=\"text-align: justify;\">Ap&oacute;s confirmado a compra ser&aacute; enviado para voc&ecirc; o cart&atilde;o fidelidade. Sempre que queira efetuar aquisi&ccedil;&atilde;o de qualquer produto ou servi&ccedil;o, dever&aacute; ser apresentado cart&atilde;o e documento de identifica&ccedil;&atilde;o, pois os benef&iacute;cios s&atilde;o individuais e intransfer&iacute;vel.</p>\r\n<p style=\"text-align: center;\"><strong>Aposte nesses benef&iacute;cios!&nbsp; Proteja seu bolso</strong></p>\r\n<div class=\"container pricing pb-5\">\r\n<div class=\"row flex-items-xs-middle flex-items-xs-center\">\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-success pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h5 class=\"card-title\">PLANO INDIVIDUAL</h5>\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>220,00</h3>\r\n<span class=\"period\">Valor por 1 ano</span> <br /><br /></div>\r\n<div class=\"card-block\">\r\n<div class=\"dropdown-divider\" style=\"border-top: 5px solid #e4a71f;\">&nbsp;</div>\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>396,00</h3>\r\n<span class=\"period\">Valor por 2 ano</span></div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">PARA AQUISI&Ccedil;&Atilde;O DE DUAS</li>\r\n<li class=\"list-group-item font-weight-bold\">ANUIDADES TEM 20% DE</li>\r\n<li class=\"list-group-item font-weight-bold\">DESCONTO NA 2&ordf; ANUIDADE</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-info pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h5 class=\"card-title\">PLANO 2 PESSOAS</h5>\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>396,00</h3>\r\n<span class=\"period\">+ 20% de desconto no 2&ordm; cadastro</span> <span class=\"period\">Valor por 1 ano</span></div>\r\n<div class=\"card-block\">\r\n<div class=\"dropdown-divider\" style=\"border-top: 5px solid #e4a71f;\">&nbsp;</div>\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>633,60</h3>\r\n<span class=\"period\">Valor por 2 ano</span></div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">PARA AQUISI&Ccedil;&Atilde;O DE DUAS</li>\r\n<li class=\"list-group-item font-weight-bold\">ANUIDADES TEM 20% DE</li>\r\n<li class=\"list-group-item font-weight-bold\">DESCONTO NA 2&ordf; ANUIDADE</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-12 col-lg-4\">\r\n<div class=\"card text-center bg-gradient-warning pt-5 pb-5\">\r\n<div class=\"card-header\">\r\n<h5 class=\"card-title\">PLANO 3 PESSOAS</h5>\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>528,00</h3>\r\n<span class=\"period\">+ 30% de desconto no 2&ordm; e 3&ordm; cadastro</span> <span class=\"period\">Valor por 1 ano</span></div>\r\n<div class=\"card-block\">\r\n<div class=\"dropdown-divider\" style=\"border-top: 5px solid #e4a71f;\">&nbsp;</div>\r\n<div class=\"card-header\">\r\n<h3 class=\"display-2\"><span class=\"currency\">R$</span>739,20</h3>\r\n<span class=\"period\">Valor por 2 ano</span></div>\r\n<ul class=\"list-group\">\r\n<li class=\"list-group-item font-weight-bold\">PARA AQUISI&Ccedil;&Atilde;O DE DUAS</li>\r\n<li class=\"list-group-item font-weight-bold\">ANUIDADES TEM 20% DE</li>\r\n<li class=\"list-group-item font-weight-bold\">DESCONTO NA 2&ordf; ANUIDADE</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<p style=\"text-align: center;\">Esse servi&ccedil;o pode ser parcelado no cart&atilde;o de cr&eacute;dito em at&eacute; 12X.</p>\r\n<p style=\"text-align: center;\"><strong><a class=\"btn btn-warning\" title=\"REALIZAR CADASTRO\" href=\"http://prosaudeintegral.com.br/inscription/clube-de-vantagens\">REALIZAR CADASTRO</a></strong></p>', '2019-07-01', '2019-07-31', '<p style=\"margin: 0cm; margin-bottom: .0001pt; text-align: justify; line-height: 150%;\">Para a Pr&oacute;-Sa&uacute;de Integral cuidar das pessoas &eacute; mais do que oferecer atendimento e servi&ccedil;os de qualidade, &eacute; proporcionar uma solu&ccedil;&atilde;o completa em sa&uacute;de integral, abrangendo os problemas relacionados a sa&uacute;de f&iacute;sica e mental, bem como o desenvolvimento pessoal.</p>\r\n<p style=\"margin: 0cm; margin-bottom: .0001pt; text-align: justify; line-height: 150%;\">Nossa filosofia &eacute; poder suprir suas necessidades de sa&uacute;de e desenvolvimento pessoal de forma acess&iacute;vel e flex&iacute;vel.</p>', '_parent', 1, NULL, '0', NULL, NULL, 2, 8, 3, '2019-07-01 15:14:13', '2019-07-01 21:37:33'),
(26, 'Clube de vantagens destaque', 'clube-de-vantagens-destaque', '1562008531.jpg', '<p>conteudo</p>', '2019-07-01', '2019-07-31', NULL, '_parent', 1, '/produtos/clube-de-vantagens', '1', NULL, NULL, 2, 2, 3, '2019-07-01 22:15:31', '2019-07-01 22:16:33'),
(27, 'Cursos e Treinamentos', 'cursos-e-treinamentos', '1574606392.jpg', '<p>Content</p>', '2019-11-24', '2019-11-23', NULL, '_parent', 1, '/treinamentos', '1', NULL, NULL, 1, 2, 3, '2019-11-24 17:39:52', '2019-12-02 14:33:20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(2, 'moderador', 'web', '2019-05-06 14:54:17', '2019-05-06 14:54:17'),
(3, 'super-admin', 'web', '2019-05-06 14:54:18', '2019-05-06 14:54:18'),
(4, 'teache', 'web', '2019-12-02 14:23:29', '2019-12-02 14:23:29'),
(5, 'student', 'web', '2019-12-02 14:23:41', '2019-12-02 14:23:41');

-- --------------------------------------------------------

--
-- Estrutura da tabela `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(2, 1),
(3, 1),
(1, 2),
(2, 2),
(3, 2),
(4, 2),
(1, 3),
(2, 3),
(3, 3),
(4, 3),
(5, 3),
(6, 3),
(7, 3),
(8, 3),
(9, 3),
(10, 3),
(11, 3),
(12, 3),
(13, 3),
(13, 4),
(13, 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sales`
--

CREATE TABLE `sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `transaction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('started','approved','canceled','pending_analysis','billet_printed','refunded','dispute','completed','blocked','chargeback','delayed','expired') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sections`
--

CREATE TABLE `sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `sections`
--

INSERT INTO `sections` (`id`, `name`, `slug`, `enabled`, `created_at`, `updated_at`) VALUES
(1, 'Global menu', 'global-menu', 1, '2019-05-06 16:55:09', '2019-05-06 16:55:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `trainees`
--

CREATE TABLE `trainees` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marital_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `some_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `have_job` tinyint(1) DEFAULT NULL,
  `office` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `career_id` int(10) UNSIGNED NOT NULL,
  `period_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `universities`
--

CREATE TABLE `universities` (
  `id` int(10) UNSIGNED NOT NULL,
  `initials` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'editor@gmail.com', '$2y$10$c.UpKG.87Xy231BKAXUk.ukYkzNDZ6M1KVO7WF3La1zECltSJQgqu', NULL, '2019-05-06 14:54:19', '2019-05-06 14:54:19'),
(2, 'moderador', 'moderador@gmail.com', '$2y$10$bNjg8XZ2fyyE8biZBWkwIetMoLiYclVy0XjGTfrxsrdxGX.FAmt5S', NULL, '2019-05-06 14:54:19', '2019-05-06 14:54:19'),
(3, 'admin', 'admin@gmail.com', '$2y$10$.oqCldqY.RZohOAbhNfJ9e8eQiEmM5gl8mf1taWMkfEeKPUYJ6yPS', NULL, '2019-05-06 14:54:19', '2019-06-05 04:33:37'),
(4, 'Pró Saúde Integral', 'psi@gmail.com', '$2y$10$CnJhh22VaNzrsf39aFEjnOzGcSC/n3g884zOBcAeHvawU8kvj0Cna', NULL, '2019-05-29 18:59:51', '2019-06-02 21:16:27'),
(5, 'Treinamento Asma', 'asma@gmail.com', '$2y$10$b0SFtfBDxMzdWT85g.CT.OmVrp1sanvZxe.S/LfLRxRBy1I/6DocC', NULL, '2020-02-28 14:26:05', '2020-02-28 14:26:05'),
(6, 'Karoliny Irineu', 'karoliny.irineu26@gmail.com', '$2y$10$ELLY9lyxfiG73SqMaxL7t.ixLdKMLhpyISfwY771zsk2nUu0oPHQa', NULL, '2020-06-22 15:45:13', '2020-06-22 15:45:13');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignments_user_id_foreign` (`user_id`),
  ADD KEY `assignments_classroom_id_foreign` (`classroom_id`);

--
-- Índices para tabela `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `careers_university_id_foreign` (`university_id`);

--
-- Índices para tabela `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Índices para tabela `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classrooms_module_id_foreign` (`module_id`);

--
-- Índices para tabela `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `courses_url_unique` (`url`),
  ADD UNIQUE KEY `courses_code_unique` (`code`),
  ADD KEY `courses_user_id_foreign` (`user_id`),
  ADD KEY `courses_category_id_foreign` (`category_id`);

--
-- Índices para tabela `course_inscription`
--
ALTER TABLE `course_inscription`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_inscription_course_id_foreign` (`course_id`),
  ADD KEY `course_inscription_inscription_id_foreign` (`inscription_id`);

--
-- Índices para tabela `inscriptions`
--
ALTER TABLE `inscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_foreign` (`menu`);

--
-- Índices para tabela `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Índices para tabela `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Índices para tabela `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modules_course_id_foreign` (`course_id`);

--
-- Índices para tabela `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`),
  ADD KEY `pages_section_id_foreign` (`section_id`),
  ADD KEY `pages_user_id_foreign` (`user_id`);

--
-- Índices para tabela `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Índices para tabela `periods`
--
ALTER TABLE `periods`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_category_id_foreign` (`category_id`),
  ADD KEY `posts_user_id_foreign` (`user_id`);

--
-- Índices para tabela `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Índices para tabela `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_user_id_foreign` (`user_id`),
  ADD KEY `sales_course_id_foreign` (`course_id`);

--
-- Índices para tabela `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sections_slug_unique` (`slug`);

--
-- Índices para tabela `trainees`
--
ALTER TABLE `trainees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainees_user_id_foreign` (`user_id`),
  ADD KEY `trainees_career_id_foreign` (`career_id`),
  ADD KEY `trainees_period_id_foreign` (`period_id`);

--
-- Índices para tabela `universities`
--
ALTER TABLE `universities`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `careers`
--
ALTER TABLE `careers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `classrooms`
--
ALTER TABLE `classrooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `course_inscription`
--
ALTER TABLE `course_inscription`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `inscriptions`
--
ALTER TABLE `inscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `periods`
--
ALTER TABLE `periods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `trainees`
--
ALTER TABLE `trainees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `universities`
--
ALTER TABLE `universities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `assignments_classroom_id_foreign` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`),
  ADD CONSTRAINT `assignments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `careers`
--
ALTER TABLE `careers`
  ADD CONSTRAINT `careers_university_id_foreign` FOREIGN KEY (`university_id`) REFERENCES `universities` (`id`);

--
-- Limitadores para a tabela `classrooms`
--
ALTER TABLE `classrooms`
  ADD CONSTRAINT `classrooms_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `courses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `course_inscription`
--
ALTER TABLE `course_inscription`
  ADD CONSTRAINT `course_inscription_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_inscription_inscription_id_foreign` FOREIGN KEY (`inscription_id`) REFERENCES `inscriptions` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_foreign` FOREIGN KEY (`menu`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Limitadores para a tabela `pages`
--
ALTER TABLE `pages`
  ADD CONSTRAINT `pages_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  ADD CONSTRAINT `pages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `trainees`
--
ALTER TABLE `trainees`
  ADD CONSTRAINT `trainees_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`),
  ADD CONSTRAINT `trainees_period_id_foreign` FOREIGN KEY (`period_id`) REFERENCES `periods` (`id`),
  ADD CONSTRAINT `trainees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
