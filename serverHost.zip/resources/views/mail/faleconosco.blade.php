<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Send Email</title>
</head>
<body>
	<b>Nome:</b>{{ $e_nome }} <br>
	<b>E-mail:</b>{{ $e_email }} <br>
	<b>Telefone: </b>{{ $e_phone }} <br>
	{{$e_message}}

</body>
</html>