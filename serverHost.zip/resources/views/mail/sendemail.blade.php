<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Send Email</title>
</head>
<body>
	<b>Nome:</b>{{ $e_nome }} <br>
	<b>E-mail:</b>{{ $e_email }} <br>
	<b>Perfil: </b>{{ $e_perfil }} <br>
	<b>Interesse: </b>{{ $e_interesse }} <br>
	{{$e_message}}

</body>
</html>