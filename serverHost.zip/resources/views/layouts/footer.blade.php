<!-- Main Footer -->
<footer class="main-footer">
    <!-- Default to the left -->
    <strong>TRAINEE FADBA </strong>
</footer>