<?php

use Faker\Generator as Faker;

$factory->define(App\Trainee::class, function (Faker $faker) {
    return [
        //
    ];
});
